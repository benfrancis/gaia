<?php

/**
 * make headers string an associative array
 * @param string $raw response headers part
 * @return array associative array of headers, if header fields get set multiple times only the latest value is used
 */
function parseHeaders($raw) {
    $res = array();
    $lines = explode("\r\n", $raw);
    for ($i = 0; $i < count($lines); $i++) {
        // if the line start with "HTTP/" or does not include a colon skip it
        if (preg_match("/^HTTP\//", $lines[$i]) || !preg_match("/^[\w\-]+\:\ /", $lines[$i])) {
            continue;
        }
        $pairs = explode(": ", $lines[$i], 2);
        $res[ $pairs[0] ] = $pairs[1];
    }
    return $res;
}

/**
 * fires an http request, CURL extension required
 *
 * @param string $url alternative parameter to take just an URL and fire a GET request by default
 *
 * @param array $options an associative array as alternative to take multiple parameters
 * @param string $options["method"] request method, i.e. GET, POST (defaults to GET)
 * @param string $options["url"] request url
 * @param array  $options["data"] optional POST data to send
 * @param int    $options["timeout"] optional timeout in seconds (defaults to 5)
 * @param array  $options["cookies"] optional array of cookies as key-value pairs
 * @param array  $options["headers"] optional array of headers as value list
 * @param array  $options["curlOptions"] optional array of CURL options as key-value pairs, see curl documentation
 *
 * @return object results of (status, headers, body, time)
 */
function curl($options) {
    if (!function_exists("curl_init")) {
        die("CURL is not available");
    }

    $defaultOptions = array(
        "method"      => "GET",
        "url"         => "",
        "data"        => NULL,
        "timeout"     => 5,
        "cookies"     => NULL,
        "headers"     => NULL,
        "curlOptions" => NULL
    );

    if (!is_array($options)) {
        $options = array("url"=>$options);
    }

    $options = array_merge($defaultOptions, $options);

    // output the request in http header for debug reasons
    if (defined("H5O_DEBUG") && H5O_DEBUG) {
        @header("X-H5O-Url: ". $options["url"]);
        @header("X-H5O-Data: ". json_encode($options["data"]));
    }

    // init curl
    $ch = curl_init();

    // set url
    curl_setopt($ch, CURLOPT_URL, $options["url"]);

    // handle uncommon request command
    if ($options["method"] != "GET" && $options["method"] != "POST") {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $options["method"]);
    }

    // prepare post data
    if ($options["method"] == "POST") {
        curl_setopt($ch, CURLOPT_POST, TRUE);
        if ($options["data"]) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($options["data"]));
        }
    }

    // prepare cookies
    if ($options["cookies"]) {
        curl_setopt($ch, CURLOPT_COOKIE, http_build_query($options["cookies"], "", ";"));
    }

    // timeout to wait for the servers
    curl_setopt($ch, CURLOPT_TIMEOUT, $options["timeout"]);

    // response will be fed to a variable
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    // follow redirects
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);

    // return headers as well
    curl_setopt($ch, CURLOPT_HEADER, TRUE);

    // decode the response e.g. for gzip
    curl_setopt($ch, CURLOPT_ENCODING, "");

    // avoid caching
    $requestHeaders = array(
        "Cache-Control: no-cache",
        "Pragma: no-cache"
    );

    // set extra headers
    if (is_array($options["headers"])) {
        $requestHeaders = array_merge($requestHeaders, $options["headers"]);
    }

    curl_setopt($ch, CURLOPT_HTTPHEADER, $requestHeaders);

    // use proxy if defined and not an empty string
    if (defined("PROXY_HOST") && PROXY_HOST) {
        curl_setopt($ch, CURLOPT_PROXY, PROXY_HOST .":". PROXY_PORT);
    }

    // set extra options
    if (is_array($options["curlOptions"])) {
        foreach ($options["curlOptions"] as $key=>$val) {
            curl_setopt($ch, $key, $val);
        }
    }

    // do the request
    $contents = curl_exec($ch);

    // i.e. timeout
    if (!$contents) {
        return (object)array("status"=>"ERROR", "headers"=>array(), "body"=>"", "time"=>FALSE);
    }

    // process results: status, headers, body
    $status     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $time       = curl_getinfo($ch, CURLINFO_TOTAL_TIME);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $headers    = substr($contents, 0, $headerSize);
    $body       = substr($contents, $headerSize );

    // close cURL session
    curl_close($ch);

    return (object)array("status"=>$status, "headers"=>parseHeaders($headers), "body"=>$body, "time"=>$time);
}
