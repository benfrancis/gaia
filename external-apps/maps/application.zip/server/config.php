<?php

//*** IMPORTANT ***************************************************************
// check the current environment with MH5_ENV and MH5_DC
// adjust all CONSTANTS below accordingly
// remember that for staging and production you might need diffent IPs than test, dev or your local machine
//*****************************************************************************

$currentDC = getenv('MH5_DC');   // possible values: 'ber01', 'esh', 'lhr', 'atl', 'pek', 'esh_legacy', 'lhr_legacy'
$currentEnv = getenv('MH5_ENV'); // possible values: 'test', 'dv', 'st', 'pr'

// error reposting level
error_reporting(E_WARNING|E_ERROR);


//*** IMPORTANT ***************************************************************
// $CONFIG will be the new Configuration structure.
//
// Add *default* options here and any custom options further down after
// deciding environments.
//*****************************************************************************

$CONFIG = array();


//*** SSO *********************************************************************

// current server path - path to /server directory, respects repositories too
$serverPath = str_replace($_SERVER["DOCUMENT_ROOT"], "", dirname(__FILE__));

//*** IMPORTANT: change keys in sso/library according to sso environment ***

$SSO_CONFIG = array(
    'ssoConnectTimeout' => 10,
    'httpTimeout'       => 10,
    'baseUrl'           => "http://" . $_SERVER["HTTP_HOST"] . $serverPath . "/sso",
    'redirect_uri'      => '/logincallback.php',
    'redirect_uri_wrapped' => '/loginwrapped_callback.php',
    'logoutDoneUrl'     => '/logoutcallback.php',
    'useSessionCookie'  => TRUE,
    'memcachedExtension'=> TRUE,
    //'cacheStorage'      => 'phpsession',
    //'sessionStorage'    => 'phpsession',

    //*** production ***
    'ssoServiceKey'     => 'd9b34ba334472c0eaadcd57d8d43dfc4',
    'client_id'         => 'd9b34ba334472c0eaadcd57d8d43dfc4',
    'client_secret'     => 'aTKehum9ctFPi0OL0wF7/3MyVnG6NuRJjjZ8zVCktMhMxqAveDtZCC2GfnfVVoHG',
    'ssoBaseUrl'        => 'https://account.nokia.com',
    'environment'       => 'production'
);

define("NPSSVR", "cpq.nokia.com");
define("NPSDEVID", 2172);
define("NPSFLAMEID", 2217);

switch ($currentDC) {
    case 'esh_legacy': // All the common stuff for the entire Eshelter/Legacy datacenter should be here
    case 'ber01': // All the common stuff for the entire Eshelter/Thor datacenter should be here
        // Proxy settings
        define("PROXY_HOST", "proxy.devbln.europe.nokia.com");
        define("PROXY_PORT", "8080");

        // server addresses
        define("SEARCHSVR",   "prod.s2g.gate5.de");
        define("PLACESSVR",   "places.nlp.nokia.com");
        define("GEOCODERSVR", "geo.nlp.nokia.com");
        define("USHARESVR",   "ushare.nokia.com");
        define("PUBTRANSSVR", "pt.svc.ovi.com");
        define("SCBESVR",     "data.nokia.com");

        // shortener service
        define("SHORTENERURL",  "https://u.it.ovi.com/urls.json");
        define("SHORTENERID",   "55");
        define("SHORTENERSECRET", "wffCSOKup4hC6wqjUyR5lQ");
        // debug flag for the dev server
        define("H5O_DEBUG", TRUE);

        switch ($currentEnv) { //any stuff that differs whithin the environments installed in this DC should be here
            case 'test':
                break;
            case 'dv':
                $SSO_CONFIG['memcacheServers'] = array ('ber01vmmh5fe001.dv.ber01.locn.s.nokia.com:11211', 'ber01vmmh5fe002.dv.ber01.locn.s.nokia.com:11211');
                break;
            default:
                error_log("no such environment");
        }
        break;
    case 'lhr_legacy': // All the common stuff for the entire Slough/Legacy datacenter should be here
        // Proxy settings
        define("PROXY_HOST", "");
        define("PROXY_PORT", "");

        // server addresses
        define("SEARCHSVR",   "10.218.5.155");
        define("PLACESSVR",   "places.nlp.nokia.com");
        define("GEOCODERSVR", "geo.nlp.nokia.com");
        define("USHARESVR",   "ushare.ovi.com");
        define("PUBTRANSSVR", "pt.svc.ovi.com");
        define("SCBESVR",     "data.nokia.com");

        // shortener service
        define("SHORTENERURL", "http://131.228.17.76:81/urls.json");
        define("SHORTENERID", "8");
        define("SHORTENERSECRET", "7EgBQWxa1MDRlxMScXNZ/w");
        define("H5O_DEBUG", FALSE);
        break;
    case 'atl':
        // Proxy settings
        define("PROXY_HOST", "");
        define("PROXY_PORT", "");

        // server addresses
        define("SEARCHSVR",   "131.228.16.114");
        define("PLACESSVR",   "places.nlp.nokia.com");
        define("GEOCODERSVR", "geo.nlp.nokia.com");
        define("USHARESVR",   "ushare.ovi.com");
        define("PUBTRANSSVR", "pt.svc.ovi.com");
        define("SCBESVR",     "data.nokia.com");

        // shortener service
        define("SHORTENERURL", "http://131.228.17.76:81/urls.json");
        define("SHORTENERID", "8");
        define("SHORTENERSECRET", "7EgBQWxa1MDRlxMScXNZ/w");
        define("H5O_DEBUG", FALSE);

        switch ($currentEnv) {
            case 'dv':
                $SSO_CONFIG['memcacheServers'] = array ('atlvmmh5fe001.dv.atl.locn.s.nokia.com:11211');
                break;
            case 'st':
                $SSO_CONFIG['memcacheServers'] = array (
                    'atlvmomwfe001.st.atl.locn.s.nokia.com:11211',
                    'atlvmomwfe002.st.atl.locn.s.nokia.com:11211'
                );
                break;
            case 'pr':
                $SSO_CONFIG['memcacheServers'] = array (
                    'atlvmomwfe001.pr.atl.locn.s.nokia.com:11211',
                    'atlvmomwfe002.pr.atl.locn.s.nokia.com:11211',
                    'atlvmomwfe003.pr.atl.locn.s.nokia.com:11211',
                    'atlvmomwfe004.pr.atl.locn.s.nokia.com:11211'
                );
                break;
            default:
                error_log("no such environment");
        }
        break;
    case 'lhr': // All the common stuff for the entire Slough/Thor datacenter should be here
        // Proxy settings
        define("PROXY_HOST", "");
        define("PROXY_PORT", "");

        // server addresses
        define("SEARCHSVR",   "131.228.16.114");
        define("PLACESSVR",   "places.nlp.nokia.com");
        define("GEOCODERSVR", "geo.nlp.nokia.com");
        define("USHARESVR",   "ushare.ovi.com");
        define("PUBTRANSSVR", "pt.svc.ovi.com");
        define("SCBESVR",     "data.nokia.com");

        // shortener service
        define("SHORTENERURL", "http://131.228.17.76:81/urls.json");
        define("SHORTENERID", "8");
        define("SHORTENERSECRET", "7EgBQWxa1MDRlxMScXNZ/w");
        define("H5O_DEBUG", FALSE);

        switch ($currentEnv) {
            case 'st':
                $SSO_CONFIG['memcacheServers'] = array (
                    'lhrvmomwfe003.st.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe004.st.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe005.st.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe006.st.lhr.locn.s.nokia.com:11211'
                );
                break;
            case 'pr':
                $SSO_CONFIG['memcacheServers'] = array (
                    'lhrvmomwfe007.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe008.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe009.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe010.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe011.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe012.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe013.pr.lhr.locn.s.nokia.com:11211',
                    'lhrvmomwfe014.pr.lhr.locn.s.nokia.com:11211'
                );
                break;
            default:
                error_log("no such environment");
        }
        break;
     case 'pek': // All the common stuff for the entire Beijing/Thor datacenter should be here
        // Proxy settings
        define("PROXY_HOST", "");
        define("PROXY_PORT", "");

        // server addresses
        define("SEARCHSVR",   "211.151.53.163");
        define("PLACESSVR",   "places.nlp.nokia.com");
        define("GEOCODERSVR", "geo.nlp.nokia.com");
        define("USHARESVR",   "ushare.nokia.com.cn");
        define("PUBTRANSSVR", "pt.svc.ovi.com");
        define("SCBESVR",     "data.nokia.com.cn");

        define("H5O_DEBUG", FALSE);

        switch ($currentEnv) { //any stuff that differs whithin the environments installed in this DC should be here
            case 'st':
                // shortener service staging
                define("SHORTENERURL", "http://10.219.142.37:81/urls.json");
                define("SHORTENERID", "3");
                define("SHORTENERSECRET", "kMAZkPyr/Gpv3HD7EJIfCw");
                $SSO_CONFIG['memcacheServers'] = array ('pekvmmh5fe001.st.pek.locn.s.nokia.com:11211', 'pekvmmh5fe002.st.pek.locn.s.nokia.com:11211');
                break;
            case 'pr':
                // shortener service production
                define("SHORTENERURL", "http://10.219.142.36:81/urls.json");
                define("SHORTENERID", "7");
                define("SHORTENERSECRET", "UttwKTk/5YVLIX6YQ6jt2A");
                $SSO_CONFIG['memcacheServers'] = array ('pekvmmh5fe001.pr.pek.locn.s.nokia.com:11211', 'pekvmmh5fe002.pr.pek.locn.s.nokia.com:11211');
                break;
            default:
                error_log('no such environment');
        }
        break;
    default: // assuming local testing
        // Proxy settings
        define("PROXY_HOST", "nokes.nokia.com");
        define("PROXY_PORT", "8080");

        // server addresses
        define("SEARCHSVR",    "prod.s2g.gate5.de");
        define("PLACESSVR",    "places.nlp.nokia.com");
        define("GEOCODERSVR",  "geo.nlp.nokia.com");
        define("USHARESVR",    "ushare.nokia.com");
        define("PUBTRANSSVR",  "pt.svc.ovi.com");
        define("SCBESVR",      "data.nokia.com");

        // shortener service
        define("SHORTENERURL", "https://u.it.ovi.com/urls.json");
        define("SHORTENERID",   "55");
        define("SHORTENERSECRET", "wffCSOKup4hC6wqjUyR5lQ");

        // debug flag for the dev server
        define("H5O_DEBUG", TRUE);
}


if (PROXY_HOST && PROXY_PORT) {
    // always define this proxy without leading http://
    $SSO_CONFIG["httpProxy"] = PROXY_HOST.":".PROXY_PORT;
}

// URLs for the APIs we are using
define("DETAILSURL",  "http://". PLACESSVR ."/places/v1/places/<placeId>?app_id=<appId>&app_code=<appCode>&tf=plain&image_dimensions=<imageDimensions>");

define("NPSURL", "http://" . NPSSVR . "/www/api.php");

// @example http://recommendations.places-api.maps.svc.ovi.com/rest/v1/recommendations/nearby/52.496159,13.3614/3/5/core/no-personal/*;lang=en-gb,callback=?pid=&app_id=&token=
define("RECOMMSURL",  "http://". PLACESSVR ."/places/v1/discover/explore/places?at=<at>&cat=<cat>&size=<size>&app_id=<appId>&app_code=<appCode>&tf=plain");
// same like RECOMMSURL but without category parameter
define("EXPLOREURL",  "http://". PLACESSVR ."/places/v1/discover/explore/places?at=<at>&size=<size>&app_id=<appId>&app_code=<appCode>&tf=plain");


// @example http://ber01vmptmet001.pt.ber01.locn.s.nokia.com:5555/bbox/v3/all.json?nostyles=1&accessId=Qechac55zebruBa5aStEvet2eqayA76U
define("PUBTRANSDISCLAIMERURL",   "http://". PUBTRANSSVR ."/bbox/v3/all.json?nostyles=1&accessId=<key>");

// @example http://pt.svc.ovi.com/metarouter/rest/stationservice/v2/stations.json?lang=en&client=m.maps.nokia.com&max=10&x=13.47&accessId=40f128241f6e9d564bb25161fd2d391e&y=52.51
define("PUBTRANSSEARCHURL", "http://". PUBTRANSSVR ."/metarouter/rest/stationservice/v2/stations.json?lang=en&client=m.maps.nokia.com&max=<limit>&x=<lon>&y=<lat>&accessId=<key>");

//** Options for PT Routing *********************
// accessId                 accessId
// client                   name of the client
// startX                   start X coordinate (longitude)
// startY                   start Y coordinate (latitude)
// start                    optional descriptive text of start location
// destX                    Destination X coordinate (longitude)
// destY                    Destination Y coordinate (latitude)
// dest                     optional descriptive text of destination location
// time                     time in yyyy-MM-ddThh:mm:ss
// arrival (optional)       switch between arrival and departure time, 0 is default (departure time) and 1 switchs to arrival time
// prod (optional)          define transportation filter, default is 1111111111111111 and means all types of transportation
// lang (optional)          language requested default to en
// backward (optional)      how many elements preceding the departure/arrival time you want to receive. The default is 0
// forward (optional)       how many elements following the departure/arrival time you want to receive. The default is 3
// routing (optional)       tt (time table), sr (simple routing) or all (for both tt and sr). The default is tt
// graph (optional)         Showing polyline of route when enabled. 1 (enabled), 0 (disabled) default is 0
// details (optional)       Showing stops (journey) of route when enabled. 1 (enabled), 0 (disabled) default is 0
// callback_func (optional) name of callback function
// callback_id (optional)   callback id to be passed
//**********************************************
// @example http://pt.svc.ovi.com/metarouter/rest/routeservice/v2/route.json?startX=13.415120&startY=52.520980&destY=52.481160&destX=13.360491&time=2012-05-30T14%3A31%3A00&accessId=40f128241f6e9d564bb25161fd2d391e&lang=en&client=m.maps.nokia.com&routing=all&arrival=0&graph=1&forward=2&prod=1111111111111111&details=1
define("PUBTRANSROUTINGURL", "http://". PUBTRANSSVR ."/metarouter/rest/routeservice/v2/route.json?startX=<slon>&startY=<slat>&destX=<dlon>&destY=<dlat>&time=<time>&accessId=<key>&lang=en&client=m.maps.nokia.com&routing=all&graph=1&details=1");

define("USHAREURL",      "http://". USHARESVR . "/api/");

define("REVERSEGEOURL",  "http://" . GEOCODERSVR ."/search/6.2/reversegeocode.json?token=<appCode>&app_id=<appId>&prox=<lat>,<lon>&mode=retrieveAddresses");

//*** SCBE ********************************************************************

//development SCBE host: data.public.devbln.europe.nokia.com
$CONFIG["SCBE_URL"] = "https://".SCBESVR."/scbe/v20/";



// version info
define("APPVERSION",   '1.8.16');
