<?php

function checkAppIdAndCode() {
    if (!isset($_GET["app_id"]) || !isset($_GET["app_code"])) {
        _fail("Credentials required");
    }
}

function checkCsrfToken() {
    $tokenShould = getCsrfToken();
    $tokenIs = $_GET['csrf_token'];

    if ($tokenShould != $tokenIs) {
        _fail("invalid csrf token");
    }
}

// by keeping the token construction/retrieval of the token in a separate function
// we'll be able to change this more easily later
function getCsrfToken() {
    return md5($_SESSION["accessToken"]);
}

function _fail($reason) {
    header("HTTP/1.0 401 Unauthorized");
    echo $reason;
    exit;
}

?>
