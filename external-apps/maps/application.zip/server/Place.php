<?php

require_once("config.php");
require_once("Http.php");

class Place {

    public static $maxImages        = 20;
    public static $maxReviews       = 5;

    public static $imageWidth       = "";
    public static $imageHeight      = "";
    public static $thumbnailWidth   = "";
    public static $thumbnailHeight  = 70;

    private static $reverseAddressCountries = array("USA", "CAN", "NZL", "IND", "GBR", "AUS", "IRL", "FRA", "LKA");

    // the places API doesn't accept 'en' or 'en-US' as valid lanuages in the accept header;
    // therefore we need to translate 'en' to 'en-US,en' to make it work (same for all other languages);
    // also make sure we use correct input capitalization so always start from lowercase string
    private static $languageTable = array(
        "en"    => "en-US,en",
        "en-us" => "en-US,en",
        "es"    => "es-MX,es",
        "pt"    => "pt-PT,pt",
        "pt-br" => "pt-BR,pt"
    );

    /**
     * Loads place details using placeId
     *
     * @param string $placeId
     * @param string $appId
     * @param string $appCode
     * @param string [$geolocation=NULL]
     * @return array formatted place object
     */
    public static function loadById($placeId, $appId, $appCode, $geolocation = NULL, $language = NULL) {
        if (!$appId || !$appCode) {
            return array("error"=>"application credentials missing");
        }

        $url = strtr(DETAILSURL, array(
            "<placeId>" => $placeId,
            "<appId>"   => $appId,
            "<appCode>" => $appCode,
            "<imageDimensions>" => implode(',', self::getImagesDimensions())
        ));
        return self::load($url, $geolocation, $language);
    }

    /**
     * Loads place details using url from search response
     *
     * @param string $placeId
     * @param string [$geolocation=NULL]
     * @return array formatted place object
     */
    public static function loadByUrl($placeUrl, $geolocation = NULL, $language = NULL) {
        $rawUrl = parse_url($placeUrl);
        $url = "{$rawUrl['scheme']}://".PLACESSVR."{$rawUrl['path']}?{$rawUrl['query']}&image_dimensions=".implode(',', self::getImagesDimensions());

        return self::load($url, $geolocation, $language);
    }

    private static function load($url, $geolocation = NULL, $language = NULL) {
        if ($geolocation) {
            $url .= '&geolocation=' . urlencode($geolocation);
        }
        if (isset($language)) {
            $language = self::$languageTable[strtolower($language)];

            if (strpos($language, "en") === FALSE) {
                $language = $language . ";q=0.8,en-US,en;q=0.3";
            }
        } else {
            $language = "en-US,en";
        }

        $data = Http::get($url, array("Accept-Language:$language"));
        return (isset($data["status"]) && $data["status"] == 404) ? array("error"=>"not found") :
                self::formatPlace($data);
    }

    /**
     * common formatting template:
     *   street houseNumber
     *   postalCode city
     *   country
     * reverted formatting template (US, Canada, New Zealand, India, GB, Australia, Ireland, Sri Lanka):
     *   houseNumber street
     *   city, district postalCode
     *   country
     *
     * @param (array) input object, properties:
         countryCode
         country
         street
         postalCode
         houseNumber
         city
         district
     */
    public static function formatAddress($address) {
        if (!$address) {
            return "";
        }

        // aligning 3L country code
        if (isset($address["countryCode3L"])) {
            $address["countryCode"] = $address["countryCode3L"];
        }

        // aligning country name
        if (isset($address["countryName"])) {
            $address["country"] = $address["countryName"];
        } else if (isset($address["localizedCountryName"])) {
            $address["country"] = $address["localizedCountryName"];
        }

        // aligning street
        if (isset($address["streetName"])) {
            $address["street"] = $address["streetName"];
        }

        // aligning postal code
        if (isset($address["zipCode"])) {
            $address["postalCode"] = $address["zipCode"];
        }

        // detect item order, depending on country
        $reverseFormat = !!(isset($address["countryCode"]) && in_array($address["countryCode"], self::$reverseAddressCountries));

        $res = array();

        if (isset($address["street"]) && $address["street"]) {
            if (isset($address["houseNumber"]) && $address["houseNumber"]) {
                $res[] = $reverseFormat ? $address["houseNumber"]." ".$address["street"] : $address["street"]." ".$address["houseNumber"];
            } else {
                $res[] = $address["street"];
            }
        }

        if (isset($address["city"]) && $address["city"]) {
            if (!$reverseFormat) {
                if (isset($address["postalCode"]) && $address["postalCode"]) {
                    $res[] = $address["postalCode"]." ".$address["city"];
                } else {
                    $res[] = $address["city"];
                }
            } else {
                $city = $address["city"];
                if (isset($address["district"]) && $address["district"]) {
                    $city .= ", ".$address["district"];
                    if (isset($address["postalCode"]) && $address["postalCode"]) {
                        $city .= " ".$address["postalCode"];
                    }
                } else {
                    if (isset($address["postalCode"]) && $address["postalCode"]) {
                        $city .= ", ".$address["postalCode"];
                    }
                }
                $res[] = $city;
            }
        }

        if (isset($address["country"]) && $address["country"]) {
            $res[] = $address["country"];
        }

        return implode("\n", $res);
    }

    /**
     * @protected
     * @param array $data raw place data object
     * @return array formatted place object
     */
    protected static function formatPlace($data) {
        // could have been updated by the backend, otherwise useless
        $placeId = $data["placeId"];

        $res = array(
            "placeId"         => $placeId,
            "name"            => $data["name"],
            "categoryGroup"   => $data["categories"][0]["id"],
            "categoryTitle"   => $data["categories"][0]["title"],
            'hasOwnerContent' => !!preg_match('#_02#', $data['icon']),
            'icon'            => $data['icon'],
            "latitude"        => $data["location"]["position"][0],
            "longitude"       => $data["location"]["position"][1],
            "address"         => $data["location"]["address"]["text"],
            "addressDetails"  => $data["location"]["address"],
            "ratingValue"     => $data["ratings"]["average"],
            "ratingCount"     => $data["ratings"]["count"]
        );

        $editorials = self::processEditorials($data['media']["editorials"]);
        if($editorials['premium']){
            $res["hasPremiumContent"] = TRUE;
        }

        if (isset($data["supplier"])) {
            $res["providerName"] = $data["supplier"]["title"];
        }

        if (isset($data["via"])) {
            $res["providerUrl"] = $data["via"]["href"];
        }

        if (isset($data["contacts"]["website"])) {
            $res["website"] = (preg_match('/^[a-z]+:\/\//', $data["contacts"]["website"][0]["value"]) ? "" : "http://")
                .$data["contacts"]["website"][0]["value"];
        }
        if (isset($data["contacts"]["email"])) {
            $res["email"] = str_replace("mailto:", "", $data["contacts"]["email"][0]["value"]);
        }
        if (isset($data["contacts"]["phone"]) && $data["contacts"]["phone"][0]) {
            $res["phone"] = $data["contacts"]["phone"][0]["value"];
        }

        $res["gallery"]        = array();
        $res["imageProviders"] = array();
        self::formatGallery($data["media"]['images']['items'], $res["gallery"], $res["imageProviders"]);

        if ($res["hasOwnerContent"]) {
            $res["ownerContent"] = $editorials['primeplace']['description'];
        }
        if ($res["hasPremiumContent"]) {
            $res["premiumContent"] = $editorials["premium"];
        }

        $res["reviews"] = self::processReviews($data["media"]["reviews"]["items"]);

        if ($res["hasOwnerContent"] && isset($data["extended"])) {
            $res["extended"] = $data["extended"];
        }

        return $res;
    }

    private static function processReviews($data){
        $ret = array();
        for ($i = 0; $i < count($data); $i++) {
            $review = $data[$i];
            $ret[] = array(
                "date"         => substr($review["date"], 0, 10),
                "title"        => $review["title"],
                "ratingValue"  => $review["rating"],
                "description"  => self::formatText($review["description"]),
                "providerIcon" => $review["supplier"]["icon"],
                "url"          => isset($review["via"]) && isset($review["via"]["href"]) ? $review["via"]["href"] : "",
                "userName"     => $review["user"]["name"]
            );
        }
        return $ret;
    }

    private static function processEditorials($data){
        $ret = array();

        if (!$data["items"]) return $ret;

        $editorials = $data["items"];
        for ($i = 0; $i < count($editorials); $i++) {
            if ($editorials[$i]["supplier"]["id"] == "primeplace") {
                $ret["primeplace"] = $editorials[$i];
                continue;
            }

            if (!isset($editorials[$i]["description"])) continue;

            $ret["premium"][] = array(
                "description"  => self::formatText($editorials[$i]["description"]),
                "providerName" => $editorials[$i]["supplier"]["title"],
                "providerUrl"  => isset($editorials[$i]["via"]) && isset($editorials[$i]["via"]["href"]) ? $editorials[$i]["via"]["href"] : "",
                "providerIcon" => $editorials[$i]["supplier"]["icon"]
            );
        }
        return $ret;
    }

    public static function resolveAllAddresses($latLon, $appId, $appCode) {
        $urls = array();
        for ($i = 0; $i < count($latLon); $i++) {
            $urls[] = strtr(REVERSEGEOURL, array(
                "<lat>"     => $latLon[$i]["lat"],
                "<lon>"     => $latLon[$i]["lon"],
                "<appId>"   => $appId,
                "<appCode>" => $appCode
            ));
        }

        $req = Http::getMulti($urls);

        $res = array();
        for ($i = 0; $i < count($req); $i++) {
            $res[] = $req[$i]["Response"]["View"][0]["Result"][0]["Location"]["Address"]["Label"];
        }

        return $res;
    }

    private static function formatText($str, $length = 0) {
        // replace <br> by \n
        $str = preg_replace('/<br( ?\/)?>/i', "\n", $str);
        // have a maximum of 2 newlines at once
        $str = preg_replace('/[\r\n\t]{2,}/', "\n\n", $str);
        // strip html tags
        $str = trim(strip_tags($str));
        // optionally truncate the string and add elipsis
        if ($length && strlen($str) > $length) {
            $str = substr($str, 0, $length)."...";
        }
        return $str;
    }

    /**
     * compress opening schedule data
     * expects an array, ordered by day and time, i.e.

        Mon: 12:00-15:00
        Tue: 12:00-15:00
        Tue: 19:00-00:00
        Wed: 12:00-15:00
        Wed: 19:00-00:00
        Thu: 12:00-15:00
        Thu: 19:00-00:00
        Fri: 12:00-15:00
        Fri: 19:00-00:00
        Sat: 19:00-00:00

     * @param <array> raw schedule data
     * @return <array> compressed schedule data
    */
    private static function compactSchedule($data) {
        if (!$data) {
            return array();
        }

        /* aggregate times by day, resulting in:

            Mon: 12:00-15:00
            Tue: 12:00-15:00, 19:00-00:00
            Wed: 12:00-15:00, 19:00-00:00
            Thu: 12:00-15:00, 19:00-00:00
            Fri: 12:00-15:00, 19:00-00:00
            Sat: 19:00-00:00
         */

        $schedule = array();
        for ($i = 0; $i < count($data); $i++) {
            $day  = $data[$i][0];
            $time = $data[$i][1];

            if (isset($schedule[$day])) {
                $schedule[$day] .= "\n$time";
            } else {
                $schedule[$day] = $time;
            }
        }

        $days = array();
        foreach ($schedule as $day=>$times) {
            $days[] = array($day, $times);
        }

        /* group days by time

            Mon: 12:00-15:00
            Tue-Fri: 12:00-15:00, 19:00-00:00
            Sat: 19:00-00:00
         */

        $res = array();
        for ($i = 0; $i < count($days); $i++) {
            $day  = $days[$i][0];
            $time = $days[$i][1];

            // check, if next day's times are the same
            $lastDay = "";
            for ($j = $i+1; $j < count($days); $j++) {
                if ($days[$j][1] != $time) {
                    break;
                }
                $lastDay = $days[$j][0];
            }

            $i = $j-1;

            if ($lastDay) {
                $res[] = array($day."-".$lastDay, $time);
            } else {
                $res[] = array($day, $time);
            }
        }

        return $res;
    }

    /**
     * extracts images and providers
     * @param <array> $data the input media data to process
     * @param <array> &$gallery a reference to the resulting list of images
     * @param <array> &$providers a reference to the resulting list of providers
     */
    private static function formatGallery($data, &$gallery, &$providers){
        for ($i = 0; $i < count($data); $i++) {
            if (self::$maxImages && count($gallery) >= self::$maxImages) {
                break;
            }

            if (isset($data[$i]["supplier"])) {
                $providers[$data[$i]["supplier"]["id"]] = array(
                    "name" => $data[$i]["supplier"]['title'],
                    "url"  => $data[$i]["via"]['href'],
                );
            }

            $dimensions = self::getImagesDimensions();

            $gallery[] = array(
                "thumbnailSrc" => $data[$i]["dimensions"][$dimensions['thumb']],
                "imageSrc"     => $data[$i]["dimensions"][$dimensions['image']],
                "providerName" => isset($data[$i]["supplier"]['title']) ? $data[$i]["supplier"]['title'] : ''
            );
        }

        $providers = array_values($providers);
    }

    private static function getImagesDimensions(){
        $tmp = array();
        if(self::$thumbnailWidth){
            $tmp[] = "w".self::$thumbnailWidth;
        }
        if(self::$thumbnailHeight){
            $tmp[] = "h".self::$thumbnailHeight;
        }
        $ret['thumb'] = implode('-', $tmp);

        $tmp = array();
        if(self::$imageWidth){
            $tmp[] = "w".self::$imageWidth;
        }
        if(self::$imageHeight){
            $tmp[] = "h".self::$imageHeight;
        }
        $ret['image'] = implode('-', $tmp);

        return $ret;
    }

}
