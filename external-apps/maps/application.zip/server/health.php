<?php
// password protection for the production server
if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_PW'] != 'html5') {
    header('WWW-Authenticate: Basic realm="MH5 Health"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Please authenticate';
    exit;
}
?>
<html>
<head><title>Health page moved</title></head>
<body>
    <a href="integration/health.php">Use the new health page instead</a>
</body>
</html>
