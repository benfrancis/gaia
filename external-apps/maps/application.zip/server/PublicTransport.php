<?php

/**
 * PublicTransport module for Places and Locations
 * can be used standalone like
 * http://yourhost.com/PublicTransport.php?lat=52.52&lon=13.37&limit=5
 *
 * all bbox check url: http://pt.svc.ovi.com/bbox/all?nostyles=1&accessid=Qechac55zebruBa5aStEvet2eqayA76U
 *
 */

require_once("config.php");
require_once("Http.php");
require_once("Place.php");

class PublicTransport {
    //pt testkey
    private static $key            = "Qechac55zebruBa5aStEvet2eqayA76U";
    //private static $key            = "40f128241f6e9d564bb25161fd2d391e";
    private static $nameSimilarity = 0.75; // minimum percentage from which station names are seen as similar
    private static $routeColor     = "#333333";
    private static $walkColor      = "#666666";
    private static $routeAlpha     = 0.75;
    private static $routeShape;

    // actions
    private static $WALK_TO   = 0;
    private static $TRAVEL_TO = 1;
    private static $ARRIVAL   = 2;

    private static function timeToSeconds($ts) {
        list($more, $mins, $secs) = explode(":", $ts);
        list($days, $hours) = explode("T", $more);
        return $secs + 60*($mins +  60*$hours);
    }

    private static function durationToSeconds($dur) {
        // "-"? + "P" + (nY + "Y")? + (nM + "M" )? + (nD + "D" )? + ("T" (nH + "H")? + (nM + "M")? + (nS + "S")?)?
        // we will not support durations longer than a day
        preg_match ('/^(-?)P(\d+Y)?(\d+M)?(\d+D)?T((\d+)H)?((\d+)M)?((\d+)S)?/' , $dur, $matches);
        $secs = $matches[10] + 60 * $matches[8] + 3600 * $matches[6];
        return ($matches[1] == "-") ? -$secs : $secs;
    }

    private static function hexToRgb($hex) {
        $int = hexdec($hex);
        $r = 0xFF & ($int>>0x10);
        $g = 0xFF & ($int>>0x8);
        $b = 0xFF & $int;
        return sprintf("rgba(%u,%u,%u,%.2F)", $r, $g, $b, self::$routeAlpha);
    }

    private static function convertToBasicPlace($data) {
        return array(
            "name"          => $data["@name"],
            "placeId"       => "pt-".str_replace("#", "-", $data["@id"]),
            "category"      => "public-transport",
            // TODO This icon url should be fetched (each time ?) from http://api.places.lbs.maps.nokia.com/places/v1/categories/places/public-transport?app_id=FLq0p5qyl-3-jTx2ANEi&app_code=0d03vSmNAytGsZfItsVBQw%253D%253D
            "icon" =>          "11.icon",
            "categoryGroup" => "transport",
            "latitude"      => floatval($data["@y"]),
            "longitude"     => floatval($data["@x"]),
            "distance"      => $data["@distance"]*1
        );
    }

    private static function getSimilarity($str1, $str2) {
        if ($str1 == $str2) {
            return 1;
        }
        $len = max(strlen($str1), strlen($str2));
        return similar_text($str1, $str2)/$len;
    }

    private static function getDisclaimerInfo($operators) {
        $url = strtr(PUBTRANSDISCLAIMERURL, array(
            "<key>"   => self::$key
        ));
        $res = Http::get($url);
        $disclaimers = array();

        foreach ($res['bboxResponse']['region'] AS $region) {
            if (isset($region['metaInfo']['operators']['op'])) {
                foreach ($region['metaInfo']['operators']['op'] AS $operator) {
                    if (isset($operator["@code"]) && in_array($operator["@code"], $operators) && !isset($disclaimers[$operator["@code"]])) {
                        //$disclaimers[$operator["@code"]] = $operator["a"]["@href"];
                        array_push($disclaimers, array("name" => $operator["@code"], "link" => $operator["a"]["@href"]));
                    }
                }
            }
        }
        return $disclaimers;
    }

    public static function find($lat, $lon, $limit = 20) {
        $url = strtr(PUBTRANSSEARCHURL, array(
            "<key>"   => self::$key,
            "<lat>"   => $lat,
            "<lon>"   => $lon,
            "<limit>" => $limit
        ));

        $data = Http::get($url);

        $stations = array();
        if (!isset($data) ||
            !array_key_exists("Res", $data) ||
            !array_key_exists("NearbyStations", $data["Res"]) ||
            !array_key_exists("Stn", $data["Res"]["NearbyStations"])) {
            return;
        }

        $stations = $data["Res"]["NearbyStations"]["Stn"];

        $res = array();
        for ($i = 0; $i < count($stations); $i++) {
            $place = self::convertToBasicPlace($stations[$i]);
            $res[] = $place;
        }

        return $res;
    }

    private static function parseLineColors($data) {
        if (!$data) {
            return;
        }

        $res = array();

        // WORKAROUND [jmarsch] another Java backend which is not able to create consistent JSON responses..
        if (!isset($data[0])) {
            $data = array($data);
        }

        for ($i = 0; $i < count($data); $i++) {
            $types = $data[$i]["transitList"]["transitType"];
            for ($j = 0; $j < count($types); $j++) {
                $typeName = $types[$j]["name"];
                $lines = $types[$j]["lineList"]["line"];
                for ($k = 0; $k < count($lines); $k++) {
                    if ($lines[$k]["name"] && $lines[$k]["color"]) {
                        $key = is_array($lines[$k]["key"]) ? $lines[$k]["key"]["$"] : $lines[$k]["key"];
                        $res[$key] = $lines[$k]["color"];
                    }
                }
            }
        }

        return $res;
    }

    private static function getLineColor($key, $colors) {
        if (isset($colors[$key])) {
            return $colors[$key];
        }
        foreach ($colors as $k=>$v) {
            if (substr($k, 0, 2) == "/^" && preg_match($k, $key)) {
                return $v;
            }
        }
        return self::$routeColor;
    }

    private static function addToShape($lat, $lon, $color) {
        self::$routeShape[] = array("lat"=>floatval($lat), "lon"=>floatval($lon), "color"=>$color);
    }

    public static function addGraphToShape($graph, $color) {
        $segments = explode(" ", $graph);
        $segmentCount = count($segments);
        for ($j = 0; $j < count($segments); $j++) {
            $segment = explode(",", $segments[$j]);
            self::addToShape($segment[0], $segment[1], $color);
        }
    }

    private static function getShape() {
        $res = array();

        $allLat = array();
        $allLon = array();

        $lastColor    = NULL;
        $currentShape = NULL;
        for ($i = 0; $i < count(self::$routeShape); $i++) {
            $item = self::$routeShape[$i];
            if ($item["color"] != $lastColor) {
                if ($currentShape) {
                    $currentShape["shape"][] = $item["lat"];
                    $currentShape["shape"][] = $item["lon"];
                    $res[] = $currentShape;
                }
                $currentShape = array("color"=>self::hexToRgb($item["color"]), "shape"=>array());
            }

            $currentShape["shape"][] = $item["lat"];
            $currentShape["shape"][] = $item["lon"];

            $lastColor = $item["color"];

            $allLat[] = $item["lat"];
            $allLon[] = $item["lon"];

            if ($currentShape && $i == count(self::$routeShape)-1) {
                $currentShape["shape"][] = $item["lat"];
                $currentShape["shape"][] = $item["lon"];
                $res[] = $currentShape;
            }
        }

        return array(
            "shape" => $res,
            "bbox" => array(
                array("latitude"=>max($allLat), "longitude"=>min($allLon)),
                array("latitude"=>min($allLat), "longitude"=>max($allLon))
            )
        );
    }

    public static function route($slat, $slon, $dlat, $dlon, $time) {
        if ($slat == $dlat && $slon == $dlon) {
            return array("error"=>"too near", "reason"=>"start equals destination");
        }

        self::$routeShape = array();

        $numChanges = 0;       // total number of changes, excludes walk
        $maneuvers  = array(); // maneuver list

        $url = strtr(PUBTRANSROUTINGURL, array(
            "<key>"  => self::$key,
            "<slat>" => $slat,
            "<slon>" => $slon,
            "<dlat>" => $dlat,
            "<dlon>" => $dlon,
            "<time>" => $time
        ));

        $data = Http::get($url);

        // no data structure
        if (!isset($data["Res"])) {
            return array("error"=>"failed", "url"=>(H5O_DEBUG ? $url : ""));
        }


        // return hafas error
        if (isset($data["Res"]["Message"]) && (isset($data["Res"]["Message"]["@level"]))) {
            $errorCode = $data["Res"]["Message"]["@level"];
            // start / end are too near
            // sample url: http://localhost:8000/server/src/PublicTransport.php?slat=52.51915&slon=13.4001&dlat=52.51814&dlon=13.4006&date=20111101T16:57
            if ($errorCode == "F" || $errorCode == "E") {
                return array("error"=>"unavailable", "url"=>(H5O_DEBUG ? $url : ""));
            }
            if ($errorCode == "W") {
                if (stristr($data["Res"]["Message"]["$"], "too near")) {
                    return array("error"=>"too near", "url"=>(H5O_DEBUG ? $url : ""));
                }
                if (stristr($data["Res"]["Message"]["$"], "no route found")) {
                    return array("error"=>"No routes found", "url"=>(H5O_DEBUG ? $url : ""));
                }
            }
        }

        // no connections
        if (!isset($data["Res"]["Connections"])) {
            return array("error"=>"unavaillable", "url"=>(H5O_DEBUG ? $url : ""));
        }

        $connectionList = $data["Res"]["Connections"];

        // no section - no real route
        if (!isset($connectionList["Connection"])) {
            return array("error"=>"No routes found", "url"=>(H5O_DEBUG ? $url : ""));
        }

        $connection = $connectionList["Connection"];

        // just use the very first connection
        if (isset($connection[0])) {
            $route = $connection[0];
        } else {
            $route = $connection;
        }

        $lastName = ""; // store name for similarity check

        // no section - no real route
        if (!isset($route["Sections"])) {
            return array("error"=>"No routes found", "url"=>(H5O_DEBUG ? $url : ""));
        }

        // just one section, usually walk
        if (!isset($route["Sections"]["Sec"][0])) {
            $route["Sections"]["Sec"] = array($route["Sections"]["Sec"]);
        }
        if (sizeof($route["Sections"]["Sec"]) == 1) {
            if (isset($route["Sections"]["Sec"][0]["Walk"])) {
                if ($route["Sections"]["Sec"][0]["Walk"]["@distance"] > 2000) {
                    return array("error"=>"unavailable", "url"=>(H5O_DEBUG ? $url : ""), "reason"=>"too far");
                } else {
                    return array("error"=>"too near", "reason"=>"only one walk segment and distance < 2km");
                }
            }
        }

        // building array of all used line colors and operators
        $lineColors = array();
        $operators = array();
        for ($i = 0; $i < count($route["Sections"]["Sec"]); $i++) {
            $section = $route["Sections"]["Sec"][$i];
            if (isset($section["Journey"])) {
                for ($l = 0, $j = $section["Dep"]["Line"]["At"]; $l < count($j); $l++) {
                    if ($j[$l]["@id"] == "color") {
                        $lineColors[$section["Dep"]["Line"]["@name"]] = $j[$l]["$"];
                    } else if ($j[$l]["@id"] == "operator") {
                        array_push($operators, $j[$l]["$"]);
                    }
                }
            }
        }

        if (sizeof($operators) >= 1) {
            $disclaimers = self::getDisclaimerInfo($operators);
        }

        for ($i = 0; $i < count($route["Sections"]["Sec"]); $i++) {
            $section = $route["Sections"]["Sec"][$i];

            if (!isset($section["Journey"]) && !isset($section["Walk"])) {
                continue;
            }

            $departureStop = $section["Dep"];
            $depTime = $departureStop["@time"];
            $lastName = $name;

            if (isset($departureStop["Addr"])) {
                // from address
                $lat  = $departureStop["Addr"]["@y"];
                $lon  = $departureStop["Addr"]["@x"];
                $name = $departureStop["Addr"]["@name"];
            } else if (isset($departureStop["Stn"])) {
                // from station
                $lat  = $departureStop["Stn"]["@y"];
                $lon  = $departureStop["Stn"]["@x"];
                $name = $departureStop["Stn"]["@name"];
            }

            // always initialize loop vars
            $action    = "";
            $duration  = "";
            $category  = "";
            $line      = "";
            $direction = "";
            $stops     = 0;
            $color     = "";

            if (isset($section["Walk"])) {
                // change (i.e. Platform A to B)
                $action   = self::$WALK_TO;
                $duration = self::durationToSeconds($section["Walk"]["@duration"]);
                $color    = self::$walkColor;

              if ($section["Graph"]) {
                  self::addGraphToShape($section["Graph"], $color);
              } else {
                    self::addToShape($lat, $lon, $color);
              }

                // identify and handle duplicate station names
                $similarity = self::getSimilarity($name, $lastName);

                // if almost identical, re-use last name and frontend will behave like identical
                // if identical, do nothing. frontend changes to "walk to LINE"
                // if names are totally different, it's a short walk. don't change names then.

                if (self::$nameSimilarity < $similarity && $similarity < 1) {
                    $name = $lastName;
                }
// check for station name if walk start doesn't have one
                if (($name == "" || $name == $lastName) && $i > 0) {
                    $departureStop = $route["Sections"]["Sec"][$i-1]["Arr"];

                    if (isset($departureStop["Addr"]) && $departureStop["Addr"]["@name"] != "") {
                        $name = $departureStop["Addr"]["@name"];
                    } else if (isset($departureStop["Stn"]["@name"]) && $departureStop["Stn"]["@name"] != "") {
                        $name = $departureStop["Stn"]["@name"];
                    }
                }
            } else if (isset($section["Journey"])) {
                $numChanges++;
                $action     = self::$TRAVEL_TO;
                $line = $section["Dep"]["Line"]["@name"];
                $dir = $section["Dep"]["Line"]["@dir"];

                if (isset($section["@uncertainty"])) {
                    $uncertainty = $section["@uncertainty"];
                }

                // arrival - start time, there is no time in the response
                $duration = self::timeToSeconds($section["Arr"]["@time"]) -
                    self::timeToSeconds($section["Dep"]["@time"]);

                $color = self::getLineColor($line, $lineColors);

                if ($section["Graph"]) {
                    self::addGraphToShape($section["Graph"], $color);
                } else {
                    self::addToShape($lat, $lon, $color);
                }
                for ($j = 1; $j < count($section["Journey"]["Stop"]); $j++) {
                    $stops++;
                    $curStop = $section["Journey"]["Stop"][$j];
                    if (!$section["Graph"] && $curStop && $curStop["Stn"] &&  $curStop["Stn"]["@x"] && $curStop["Stn"]["@y"]) {
                        self::addToShape($curStop["Stn"]["@y"], $curStop["Stn"]["@x"], $color);
                    }
                }
            }

            $maneuvers[] = array(
                "name"      => $name,
                "action"    => $action,
                "position"  => array("latitude"=>floatval($lat), "longitude"=>floatval($lon)),
                "duration"  => $duration,
                "category"  => trim($category),
                "line"      => $line,
                "direction" => $dir,
                "stops"     => $stops,
                "color"     => $color,
                "depTime"   => $depTime
            );
        }

        // insert the destination
        $dest  = $route["Arr"]["Addr"];
        $color = self::$routeColor;
        self::addToShape($dest["@y"], $dest["@x"], $color);
        $shape = self::getShape();

        $maneuvers[] = array(
            "name"      => $dest["@name"],
            "action"    => self::$ARRIVAL,
            "position"  => array("latitude"=>floatval($dest["@y"]), "longitude"=>floatval($dest["@x"])),
            "duration"  => 0,
            "category"  => "",
            "line"      => "",
            "direction" => "",
            "stops"     => 0,
            "color"     => $color
        );

        $res = array(
            "response" => array(
                "route" => array(
                    "shape"   => $shape["shape"],
                    "summary" => array(
                        "baseTime"      => self::durationToSeconds($route["@duration"]),
                        "numChanges"    => max($numChanges-1, 0),
                        "error"         => 0,
                        "bbox"          => $shape["bbox"] ,
                        "url"           => H5O_DEBUG ? $url : "",
                        "uncertainty"   => $uncertainty ? $uncertainty : 0
                    ),
                    "maneuvers" => $maneuvers
                )
            )
        );

        if (isset($disclaimers)) {
            $res["response"]["route"]["summary"]["disclaimers"] = $disclaimers;
        }

        return $res;
    }

    public static function autoResponse($param = NULL) {
        if (!$param || !is_array($param)) {
            return;
        }

        if (basename($_SERVER["PHP_SELF"]) != basename(__FILE__)) {
            return;
        }

        // calculate route from lat/lon to lat/long at given time
        if (isset($param["slat"]) && isset($param["slon"]) &&
            isset($param["dlat"]) && isset($param["dlon"]) &&
            isset($param["date"])) {

            $res = self::route(
                $param["slat"], $param["slon"],
                $param["dlat"], $param["dlon"],
                $param["date"]
            );
            Http::response($res);
        }
    }
}

// check, if this got called directly, decide response action according to parameters
PublicTransport::autoResponse($_GET);
