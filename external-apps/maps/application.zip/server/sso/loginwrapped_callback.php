<?php

$isPhpSdk = !isset($_REQUEST["jsSdkId"]);

// set include path to find library folder
set_include_path(realpath("./library/").PATH_SEPARATOR.get_include_path());

require_once("Nokia/Sso/WebOauth2.php");
require_once("../config.php");
require_once("../security.php");

$sso = Nokia_Sso_WebOauth2::getInstance();
$sso->setConfig($SSO_CONFIG);

$sso->startSession();
$sso->createSession();

$data = array();

// if (isset($_SESSION["accessToken"])) {
//     $data["accessToken"] = $_SESSION["accessToken"];
// }

if (isset($_SESSION["accesstokenInfo"])) {
    $data["accountid"]    = $_SESSION["accesstokenInfo"]["accountid"];
    $data["validuntil"]   = $_SESSION["accesstokenInfo"]["validuntil"]*1;
    $greetingName = explode("@", $_SESSION["accesstokenInfo"]["greetingname"]);
    $data["greetingname"] = $greetingName[0];
}

if (isset($_SESSION["accesstokenExtInfo"])) {
    if ($_SESSION["accesstokenExtInfo"]["username"]) {
        $data["username"] = $_SESSION["accesstokenExtInfo"]["username"];
    }
    if ($_SESSION["accesstokenExtInfo"]["legacy_token"]) {
        $data["legacy_token"] = $_SESSION["accesstokenExtInfo"]["legacy_token"];
    }
}

$data['csrf_token'] = getCsrfToken();

header('Location: loginwrapped.php?data='. urlencode(json_encode($data)));
?>
