<?php
class OAuth2AccessToken_AuthenticationType extends PBEnum
{
  const NOT_KNOWN  = 0;
  const ACCESS_TOKEN  = 1;
  const MANUAL_LOGIN  = 2;
  const REFRESH_TOKEN  = 3;
  const REMEMBER_ME  = 4;
  const MD5_DIGEST  = 5;
  const REQUEST_TOKEN  = 6;
  const PARTNER_TOKEN  = 7;
  const FEDERATION  = 8;
  const CLIENT_CREDENTIALS  = 9;
}
class OAuth2AccessToken extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBInt";
    $this->values["2"] = "";
    $this->fields["3"] = "OAuth2AccessToken_AuthenticationType";
    $this->values["3"] = "";
    $this->fields["4"] = "PBString";
    $this->values["4"] = "";
    $this->fields["5"] = "PBString";
    $this->values["5"] = "";
    $this->fields["6"] = "PBString";
    $this->values["6"] = "";
    $this->fields["7"] = "PBString";
    $this->values["7"] = "";
    $this->fields["8"] = "PBBool";
    $this->values["8"] = "";
  }
  function id()
  {
    return $this->_get_value("1");
  }
  function set_id($value)
  {
    return $this->_set_value("1", $value);
  }
  function validUntil()
  {
    return $this->_get_value("2");
  }
  function set_validUntil($value)
  {
    return $this->_set_value("2", $value);
  }
  function authenticationType()
  {
    return $this->_get_value("3");
  }
  function set_authenticationType($value)
  {
    return $this->_set_value("3", $value);
  }
  function creator()
  {
    return $this->_get_value("4");
  }
  function set_creator($value)
  {
    return $this->_set_value("4", $value);
  }
  function originator()
  {
    return $this->_get_value("5");
  }
  function set_originator($value)
  {
    return $this->_set_value("5", $value);
  }
  function greetingName()
  {
    return $this->_get_value("6");
  }
  function set_greetingName($value)
  {
    return $this->_set_value("6", $value);
  }
  function accountId()
  {
    return $this->_get_value("7");
  }
  function set_accountId($value)
  {
    return $this->_set_value("7", $value);
  }
  function legacyToken()
  {
    return $this->_get_value("8");
  }
  function set_legacyToken($value)
  {
    return $this->_set_value("8", $value);
  }
}
class OAuth2AccessTokenExtension extends PBMessage
{
  var $wired_type = PBMessage::WIRED_LENGTH_DELIMITED;
  public function __construct($reader=null)
  {
    parent::__construct($reader);
    $this->fields["1"] = "PBString";
    $this->values["1"] = "";
    $this->fields["2"] = "PBString";
    $this->values["2"] = "";
    $this->fields["3"] = "PBString";
    $this->values["3"] = "";
    $this->fields["4"] = "PBFixed64";
    $this->values["4"] = "";
  }
  function legacyToken()
  {
    return $this->_get_value("1");
  }
  function set_legacyToken($value)
  {
    return $this->_set_value("1", $value);
  }
  function userName()
  {
    return $this->_get_value("2");
  }
  function set_userName($value)
  {
    return $this->_set_value("2", $value);
  }
  function compatibilityUserName()
  {
    return $this->_get_value("3");
  }
  function set_compatibilityUserName($value)
  {
    return $this->_set_value("3", $value);
  }
  function scope()
  {
    return $this->_get_value("4");
  }
  function set_scope($value)
  {
    return $this->_set_value("4", $value);
  }
}
?>