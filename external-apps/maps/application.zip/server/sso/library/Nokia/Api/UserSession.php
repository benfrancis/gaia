<?php
/** Nokia_Sso_Api */
require_once 'Nokia/Sso/Api.php';
/** Protobuf files */
require_once('Protocolbuf/message/pb_message.php');
require_once('Protocolbuf/pb_proto_Oauth2AccessToken.php');

/**
 * NoA server PHP SDK - This class contains all API implementation
 * related to token.
 */
class Nokia_Api_UserSession extends Nokia_Sso_Api
{
		private $_configApi = array(
	        'ssoUrlTokenCreate'  => '/rest/1.0/tokens',
			'ssoUrlTokenInfo' => '/rest/1.0/tokens/%s',
			'ssoUrlExchangeTokenOauth1toOauth2'	=> '/rest/1.0/tokens/%s/oauth20'
		);

		/**
		 * Key used at APC caching (if available)
		 * @var string $apcKey
		 */
		static public $apcKey = "NokiaApiUserSessionSingleton";

		/**
		 * Singleton instance of Nokia_Api
		 * @var Nokia_Api_UserSession $_instance
		 */
		static private $_instance;

		/**
		 * Get singleton intance
		 * @return Nokia_Api_UserSession
		 */
		static public function getInstance()
		{
			// check if cache enabled
			$cache = function_exists('apc_store');
			// check if instance exists already
			if (!(self::$_instance instanceof self)) {
				self::$_instance = new self();
				if ($cache) { // store into cache if available
					apc_store(Nokia_Api_UserSession::$apcKey, self::$_instance);
				}
			}
			// return instance from cache if available
			return $cache ? apc_fetch(Nokia_Api_UserSession::$apcKey) : self::$_instance;
		}

		/**
		 * Set configuration array.
		 * @see trunk/library/Nokia/Sso/Nokia_Sso_Api::setConfig()
		 */
		public function setConfig(array $config)
		{
			return parent::setConfig(array_merge($this->_configApi, $config));
		}

		/**
		 * API to authenticate with HashPassword with $username and $password
		 * @access Public
		 * @param string $username
		 * @param string $password
		 * @throws Exception When login fails.
		 * @return array Assoc array containing tokenInfo and userInfo arrays.
		 */
		public function doLogin($username, $password)
		{
			$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<tokenCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
</tokenCreationRequest>
XML;
			if(empty($username))
			throw new Exception("Username Required");

			if(empty($password))
			throw new Exception("Password Required");

			//create simplexml object
			$xml = simplexml_load_string($xmlString);
			$nonce = md5(microtime() . mt_rand()); //generate new nonce (different from request Authorization)
			$timestamp = time(); //generate timestamp
			//add more elements into xml
			$resourceId = '/accounts/' . $this->idna_toAscii($username) . '/';
			$digestAuthNode = $xml->addChild('digestAuth');
			$digestAuthNode->addChild('username', $this->idna_toAscii($username));
			$digestAuthNode->addChild('nonce', $nonce);
			$digestAuthNode->addChild('created', $timestamp);
			$digestAuthNode->addChild('digest', base64_encode( sha1($nonce . $timestamp . base64_encode( sha1($resourceId . $password,true)) ,true)));

			//make the request
			$responseXml = $this->requestTokenCreate($xml);
			$this->setToken(new OAuthToken((string) $responseXml->tokenInfo->token, (string) $responseXml->tokenInfo->tokenSecret));

			$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
			$responseXml->userInfo->email = $unicode_email;
			return $responseXml;
		}

		/**
		 * API to retrieve a user session by exchanging a request token.
		 * @access Public
		 * @param string $token Request token
		 * @return XML SimpleXMLObject
		 */
		public function createFromRequestToken($token)
		{
			$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<tokenCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<requestToken></requestToken>
</tokenCreationRequest>
XML;
			if(empty($token))
			throw new Exception("Invalid Message Format::Request Token cannot be Null");
			$xml = simplexml_load_string($xmlString);
			$xml->requestToken = $token;

			$responseXml = $this->signedRequest(
			$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlTokenCreate'],
            'POST',
			array(
                'XMLContent' => $xml->asXml()
			)
			);

			$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
			$responseXml->userInfo->email = $unicode_email;
			return $responseXml;

		}

		/**
		 * API to make token refresh request into Nokia Account.
		 * @access Public
		 * @param string $token
		 * @return XML SimpleXMLObject
		 */
		public function requestTokenRefresh($token,$tokenSecret)
		{
			if(empty($token))
			throw new Exception("Invalid Message Format::Request Token cannot be Null");

			if(empty($tokenSecret))
			throw new Exception("Invalid Message Format::Request Token Secret cannot be Null");

			$this->setToken(new OAuthToken((string)$token,(string)$tokenSecret));
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $token, $this->_config['ssoUrlTokenInfo']),
            'PUT'
            );
		}

		/**
		 * API to make tokenInfo request into  Nokia Account.
		 * @access Public
		 * @param string $token
		 * @return XML SimpleXMLObject
		 */
		public function requestTokenInfo($token)
		{
			if(empty($token))
			throw new Exception("Invalid Message Format::Request Token cannot be Null");

			$responseXml = $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $token, $this->_config['ssoUrlTokenInfo'])
			);

			$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
			$responseXml->userInfo->email = $unicode_email;
			return $responseXml;
		}


		/**
		 * API to retrieve a user session by exchanging an access token.
		 * @access Public
		 * @param string $token Access token
		 * @param string $tokenSecret Access token Secret
		 * @return XML SimpleXMLObject
		 */
		public function exchangeToken($token,$tokenSecret)
		{
			$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<tokenCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<accessToken></accessToken>
</tokenCreationRequest>
XML;
			if(empty($token))
			throw new Exception("Invalid Message Format::Request Token cannot be Null");

			if(empty($tokenSecret))
			throw new Exception("Invalid Message Format::Request Token Secret cannot be Null");

			$this->setToken(new OAuthToken((string)$token,(string)$tokenSecret));

			$xml = simplexml_load_string($xmlString);
			$xml->accessToken = $token;

			$responseXml = $this->signedRequest(
			$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlTokenCreate'],
            'POST',
			array(
                'XMLContent' => $xml->asXml()
			)
			);

			$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
			$responseXml->userInfo->email = $unicode_email;
			return $responseXml;
		}

		/**
		 * API to invalidate/delete an active user session/token.
		 * @access Public
		 * @param String $token
		 */
		public function deleteToken($token,$tokenSecret)
		{
			if(empty($token))
			throw new Exception("Invalid Message Format::Token cannot be Null");
			if(empty($tokenSecret))
			throw new Exception("Invalid Message Format::Token Secret cannot be Null");
			$this->setToken(new OAuthToken((string)$token,(string)$tokenSecret));
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $token, $this->_config['ssoUrlTokenInfo']),
            'DELETE'
            	);
		}

		/**
		 * API to exchange OAuth 1.0 access token into OAuth 2.0.
		 * @access Public
		 * @param string $token OAuth1.0 token
		 * @param string $tokenSecret OAuth1.0 token secret
		 * @return OAuth 2.0 Token details
		 */
		public function exchangeOAuth1TokenIntoOAuth2($token, $tokenSecret){
			if(empty($token))
				throw new Exception("Invalid Message Format::Token cannot be Null or Empty");
			if(empty($tokenSecret))
				throw new Exception("Invalid Message Format::Token Secret cannot be Null or Empty");
			$this->setToken(new OAuthToken((string)$token,(string)$tokenSecret));
			$oauth2AccessToken = $this->signedRequest($this->_config['ssoBaseUrl']. str_replace('%s', $token, $this->_config['ssoUrlExchangeTokenOauth1toOauth2']));

			list($accessTokenInfo, $accessTokenExtInfo) = $this->decryptOpaqueToken($oauth2AccessToken->accessToken);

			$accountId = bin2hex($accessTokenInfo->accountId());
			$formattedAccountId = preg_replace("/^([a-z0-9]{8})([a-z0-9]{4})([a-z0-9]{4})([a-z0-9]{4})([a-z0-9]{12})$/i", "$1-$2-$3-$4-$5", $accountId);

			$accessTokenData = array();
			if (!empty($accessTokenInfo)){
				$accessTokenData = array(
				'accesstokenInfo'			=> array(
					'tokenid'				=> (string) bin2hex($accessTokenInfo->id()),
					'accountid'				=> (string) $formattedAccountId,
					'validuntil'			=> (string) $accessTokenInfo->validUntil(),
					'greetingname'			=> (string) $accessTokenInfo->greetingName(),
					'authenticationtype'	=> 'ACCESS_TOKEN',
					'creator'				=> (string) bin2hex($accessTokenInfo->creator()),
					'originator'			=> (string) bin2hex($accessTokenInfo->originator())
				));
			}

			if (!empty($accessTokenExtInfo)){
				$accessTokenData['accesstokenExtInfo']	= array(
					'legacy_token'				=> (string) $accessTokenExtInfo->legacyToken(),
					'username'					=> (string) $accessTokenExtInfo->userName(),
					'compatibilityusername'		=> (string) $accessTokenExtInfo->compatibilityUserName());
			}
			return $accessTokenData;
		}

		/**
		 * Request new token creation with $username and $password.
		 * @access Private
		 * @param SimpleXMLObject $xml
		 */
		private function requestTokenCreate($xml)
		{
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlTokenCreate'],
            'POST',
			array(
                'XMLContent' => $xml->asXml()
			)
			);
		}
}
?>