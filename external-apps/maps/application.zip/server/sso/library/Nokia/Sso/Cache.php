<?php
/**
 * Nokia SSO library - session handling.
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Cache
{
	/**
	 * Key used at APC caching (if available)
	 * @var string $apcKey
	 */
	static public $apcKey = "NokiaSsoCacheSingleton";

	/**
	 * Singleton instance of Nokia_Sso_Cache
	 * @var Nokia_Sso_Cache $_instance
	 */
	static private $_instance;

	private $_name, $_id, $_storage = null;
	private $_config = array();

	/**
	 * Get singleton intance
	 * @return Nokia_Sso_Cache
	 */
	static public function getInstance() {
		// check if instance exists already
		if (!(self::$_instance instanceof self)) {
			self::$_instance = new self();
			if (function_exists('apc_store')) { // store into cache if available
				apc_store(Nokia_Sso_Cache::$apcKey, self::$_instance);
			}
		}
		// return instance from cache if available
		return (function_exists('apc_fetch')) ? apc_fetch(Nokia_Sso_Cache::$apcKey) : self::$_instance;
	}

	/**
	 * Get current configuration
	 * @param string $key Optional key of the configuration
     * @return string|array
	 */
	public function getConfig($key = null) {
		if ($key) {
			return isset($this->_config[$key]) ? $this->_config[$key] : null;
		} else {
			return $this->_config;
		}
	}

	/**
	 * Set configuration array. See manual for available keys.
	 * @param array $config Assoc array of configuration
	 * @return $this
	 */
	public function setConfig(array $config) {
		$this->_config = array_merge($this->_config, $config);
		return $this;
	}

	/**
	 * Get data from cache with $key
	 * @param string $key
	 */
	public function get($key) {
		return $this->_getStorage()->get($key);
	}

	/**
	 * Set data into cache with $key
	 * @param string $key
	 * @param string $value
	 * @param int $lifeTime
	 */
	public function set($key, $value, $lifeTime = null) {
		$lifeTime = ($lifeTime !== null) ? $lifeTime : $this->_config['cacheLifetime'];
		$this->_getStorage()->set($key, $value, $lifeTime);
	}

	/**
	 * Get session storage object
	 * @return Nokia_Sso_Storage_Abstract
	 */
	private function _getStorage() {
		if ($this->_storage === null) {
			switch ($this->_config['cacheStorage']) {
				case 'memcache':
					require_once 'Nokia/Sso/Storage/Memcache.php';
					$this->_storage = new Nokia_Sso_Storage_Memcache($this->_config);
				break;

                case 'phpsession':
				default:
					require_once 'Nokia/Sso/Storage/PhpSession.php';
					$this->_storage = new Nokia_Sso_Storage_PhpSession($this->_config);
					break;
			}
		}
		return $this->_storage;
	}
}