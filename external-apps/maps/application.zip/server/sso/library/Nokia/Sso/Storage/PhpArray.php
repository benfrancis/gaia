<?php
/** Nokia_Sso_Storage_Interface */
require_once  'Nokia/Sso/Storage/Interface.php';

/**
 * Nokia SSO library - session handling using native PHP array as 'backend'. Note that this is only for testig purposes!
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Storage_PhpArray implements Nokia_Sso_Storage_Interface
{
    private $data = array();

	/**
	 * Constructor
	 * @param array $config
	 */
	public function __construct($config) {
	}

	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::get()
	 */
	public function get($key) {
		return isset($this->data[$key]) ? $this->data[$key] : array();
	}

	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::set()
	 */
	public function set($key, $value, $lifeTime) {
	    $this->data[$key] = $value;
	}

	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::delete()
	 */
	public function delete($key) {
	    unset($this->data[$key]);
	}
}