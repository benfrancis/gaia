<?php
/** Nokia_Sso_Core */
require_once 'Nokia/Sso/Core.php';
/** Nokia_Sso_Session */
require_once 'Nokia/Sso/Session.php';
/** Protobuf files */
require_once('Protocolbuf/message/pb_message.php');
require_once('Protocolbuf/pb_proto_Oauth2AccessToken.php');

/**
 * Nokia SSO library - Web site interface which uses OAuth 2.0 protocol
 */
class Nokia_Sso_WebOauth2 extends Nokia_Sso_Core
{
	/**
	 * Key used at APC caching (if available)
	 * @var string $apcKey
	 */
	static public $apcKey = "NokiaSsoWebOauth2Singleton";

	/**
	 * Singleton instance of Nokia_Sso_Session
	 * @var Nokia_Sso_Session $_instance
	 */
	static private $_instance;

	/**
	 * A CSRF state variable to assist in the defense against
	 * CSRF attacks.
	 */
	protected $_state;

	/**
	 * Ascope variable which stores the Scope value that is passed.
	 */
	protected $_scope;

	/**
	 * Web interface specific configuration.
	 */
	private $_defaults = array(
	    'linkLabelLogout'          => 'Logout',
	    'linkLabelLogin'           => 'Login',
	    'linkAttributesLogout'     => array(),
	    'linkAttributesLogin'      => array(),
	    'linkHrefLogout'           => 'logout.php'
	    );

	 /*
	  * For building current URL, we don't need few query parameters related to OAuth 2.0 protocol
	  */
	 protected $_dropqueryparams = array(
	    'code',
	    'state',
	 	'ns',
	 	'scope',
	 	'jsSdkId',
	 	'jsCallbackUrl'
  	);

    /**
     * Get singleton intance
     * @return Nokia_Sso_WebOauth2
     */
    static public function getInstance() {
    	// check if instance exists already
    	if (!(self::$_instance instanceof self)) {
    		self::$_instance = new self();
    		if (function_exists('apc_store')) { // store into cache if available
    			apc_store(Nokia_Sso_WebOauth2::$apcKey, self::$_instance);
    		}
    	}
    	// return instance from cache if available
    	return function_exists('apc_fetch') ? apc_fetch(Nokia_Sso_WebOauth2::$apcKey) : self::$_instance;
    }



	 /**
	  * Set configuration array. See manual for available keys.
	  * @param array $config Assoc array of configuration
	  * @return self
	  */
	  public function setConfig(array $config) {
	   	$defaultsKeys = array_keys($this->_defaults); // get web specific keys
	   	$defaultsConfig = array();
	   	foreach ($defaultsKeys as $key) { // loop all web specific keys
	   		if (isset($config[$key])) {
	   			$defaultsConfig[$key] = $config[$key]; // store for later use
	   			unset($config[$key]); // unset from core configs
	   		}
	   	}
	   	$this->_defaults = count($defaultsConfig) ? // new config to set?
	   	array_merge($this->_defaults, $defaultsConfig) : // merge
	   	$this->_defaults; // use old
	   	return parent::setConfig($config); // set core configs
	   }

	    /**
	     * Start session. Used in the same way as 'session_start()'.
	     * @param string $id Session ID
	     * @param boolean $checkLastLoginCookie if set to true which is default value, SDK checks for NoALastLogin
	     * cookie presence before redirecting to Nokia Account server only in a case where $forceLogin is set to 'false'.
	     * @param boolean $forceLogin if set to true, Nokia Login page is displayed to user. Default value is
	     * false which tries to fetch existing user session from Nokia Account without prompting user for credentials.
	     * @param string $scope comma separated list of requested permissions
	     * @return Nokia_Sso_WebOauth2
	     */
	    public function startSession($id = null, $checkLastLoginCookie = true, $forceLogin = false, $scope = null)
	    {
	    	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);

	    	//check for scope parameter
			if (!empty($scope)) {
				$this->_scope = $scope;
			}

	    	//check NoALastLogin cookie
	    	if ($checkLastLoginCookie)
	    		isset($_COOKIE['NOALastLogin'])?$checkLastLoginCookie = true:$checkLastLoginCookie = false;
	    	else
	    		$checkLastLoginCookie = true;

	    	if ($id !== null) {
	    		$session->setId($id);
	    	}
	    	$session->start();

	    	// user not having valid session and NoALastLogin cookie present? -> joinsso
	    	if (!isset($_SESSION['accesstokenInfo']) && !isset($_REQUEST['code']) && $checkLastLoginCookie && !isset($_GET['ns']))
	    	{
	    		$this->_redirectJoinSso($forceLogin);
	    	}
	    	return $this;
	    }

	    /**
	    * start a session if there is a valid response after login
	    * @return Nokia_Sso_WebOauth2
	    */
	    public function createSession()
	    {
	    	//get an opaque access token
	    	$response = $this->getAccessToken();

	    	if (!empty($response))
	    	{
		    	$response = explode('&',$response);

				// prepare parameters as array
				for ($i = 0; $i < count($response); $i++) {
					list($key, $value) = explode("=", $response[$i],2);
					unset($response[$i]);
					$response[$key] = $value;
				}

		    	//need to decrypt opaque access token
		    	list($accessTokenInfo, $accessTokenExtInfo) = $this->decryptOpaqueToken($response['access_token']);

		    	$accountId = bin2hex($accessTokenInfo->accountId());

		    	$formattedAccountId = preg_replace("/^([a-z0-9]{8})([a-z0-9]{4})([a-z0-9]{4})([a-z0-9]{4})([a-z0-9]{12})$/i", "$1-$2-$3-$4-$5", $accountId);

		    	$sessionData = array();

		    	if (!empty($accessTokenInfo))
		    	{
		    		$sessionData = array(
					'accesstokenInfo'			=> array(
						'tokenid'				=> (string) bin2hex($accessTokenInfo->id()),
						'accountid'				=> (string) $formattedAccountId,
		    			'validuntil'			=> (string) $accessTokenInfo->validUntil(),
		    			'greetingname'			=> (string) $accessTokenInfo->greetingName(),
		    			'authenticationtype'	=> 'ACCESS_TOKEN',
		    			'creator'				=> (string) bin2hex($accessTokenInfo->creator()),
		    			'originator'			=> (string) bin2hex($accessTokenInfo->originator()),
		    			'token_type'			=> (string) $response['token_type'],
		    			'expires'				=> (string) $response['expires_in'],
		    			'refresh_token'			=> (string) $response['refresh_token']
		    		));
		    	}

                $sessionData['accessToken'] = urldecode($response['access_token']);

		    	if (!empty($accessTokenExtInfo))
		    	{
		    		$sessionData['accesstokenExtInfo']	= array(
						'legacy_token'				=> (string) $accessTokenExtInfo->legacyToken(),
		    			'username'					=> (string) $accessTokenExtInfo->userName(),
		    			'compatibilityusername'		=> (string) $accessTokenExtInfo->compatibilityUserName(),
		    			'scope'						=> $this->getScopeValue($accessTokenExtInfo->scope()));
		    	}

		    	// create cookie before starting session!
	    		$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
	    		$session->setCookie();

	    		// start session
	    		$this->startSession((string) $accessTokenExtInfo->legacyToken(), false);

	    		// populate session with data
	    		$_SESSION = array_merge($_SESSION, $sessionData);

	    		// remember to set NOALastLogin cookie in place
	    		$this->setNoaLastLoginCookie();
	    	}
    		return $this;
	    }


	    /**
	     * Method to return valid user access token information using authorization code
	     * @return String a valid user access token, or false if not found
	     */
	    protected function getAccessToken() {
	    	//get authorization code from request
	    	$code = $this->getCode();


	    	if ($code) {
	    		/* Note: Replay attack is being handled by Nokia account server.*/
	    		$access_token = $this->getAccessTokenFromCode($code);

	    		if ($access_token) {
	    			return $access_token;
	    		}
	    		return false;
	    	}
	    }

	    /**
	     * Get access token using authorization code
	     * @param string valid authorization code, or false if not found
	     */
	    private function getAccessTokenFromCode($code)
	    {
	    	if (empty($code))
	    		return false;

	    	$parameters = array('grant_type' => 'authorization_code',
     					  'client_id' => $this->_config['client_id'],
     					  'code' => $code,
                          'redirect_uri' => $this->getCurrentUrl(),
     					  'client_secret' => $this->_config['client_secret']);

	    	if (isset($_REQUEST['scope']) && ($_REQUEST['scope'] != null))
				$parameters = array_merge($parameters, array('scope'=>$_REQUEST['scope']));

          	// get access token info from Nokia Account
			$accessTokenResponse = $this->_requestUrl(
							$this->getUrl($this->_config['ssoBaseUrl'], $this->_config['ssoUrlOauth2AccessToken']),
							null,'POST',$parameters);
			if (empty($accessTokenResponse))
      			return false;

		    return $accessTokenResponse;
	    }

		/**
		 * Method to return authorization code from the query parameters or return false.
		 * @return string the authorization code, or false if authorization code not found.
		 */
		 protected function getCode() {
		    if (isset($_REQUEST['code'])) {
              if (isset($_REQUEST['jsSdkId'])) {
                return $_REQUEST['code'];
              }
		      if (isset($_REQUEST['state'])) {
		      //check if received state in request is present in cache
		   	  $this->_state = $this->getCache()->get('state'.$_REQUEST['state']);

		      if (is_array($this->_state)) { //this case can occur when phpsession storage is enabled.very less changes but possible.
		      	foreach ($this->_state as $k=>$v){
		      		if(strpos($k, "state") === 0)
		      			$this->_state = 1;
		      	}
		      }

		      //if state found in cache with the value 1, it is valid state
		      if ($this->_state == 1 && isset($_REQUEST['state'])) {
		        //state validation task is done so clear state
		        $this->_state = null;
		        return $_REQUEST['code'];
		      }
		      }
		      elseif(!isset($_REQUEST['state'])) {
		      	 $currentUri = str_replace($this->_config['baseUrl'],'', $this->getCurrentUrl());
		      	 if ($currentUri == $this->_config['embeddedUIUrl'])
		      	 	  return $_REQUEST['code'];
		      }else {
		        throw new Exception('state does not match.');
		      }
		    }
		    else if (isset($_REQUEST['error'])){
	    		throw new Exception($_REQUEST['error']);
	    	}
		    return false;
		}

		/**
	     * Redirect user into NoA portal for 'joinsso' using Location header.
	     * @param boolen $forceLogin Optional param to force login screen.
	     */
	    private function _redirectJoinSso($forceLogin = false) {
	    	$header = "Location: " . $this->_generateJoinSsoUrl($forceLogin);
	    	header($header);
	    }

	    /**
	     * Generate URL that point into NoA server for joinsso use.
	     * If $forceLogin is set then user will see NoA login page.
	     * @param boolen $forceLogin Optional param to force login screen.
	     * @return NoA redirect URL
	     */
	    public function _generateJoinSsoUrl($forceLogin = false) {
	    	$this->setState();
	    	$redirectUri = !empty($this->_config['redirect_uri'])?$this->_config['baseUrl'].$this->_config['redirect_uri']:$this->getCurrentUrl();
	    	if ($forceLogin === false)
		    	$redirectUri.= '?ns=true';

	    	$params = array_merge(array(
		                    'client_id' => $this->_config['ssoServiceKey'],
		                    'redirect_uri' => $redirectUri,
		      				'response_type' => 'code',	//default grant type is authorization code
		      				'state' => $this->_state));

	    	//Check for scope parameter
	    	if (!empty($this->_scope)) {
	    		$params['scope']  = $this->_scope;
	    	}

	    	//Omniture Parameters which needs to be added by service application in request are added to JoinSsoUrl
	    	if(!empty($_REQUEST['c6']))	$params['c6']  = $_REQUEST['c6'];
	    	if(!empty($_REQUEST['ch']))	$params['ch']  = $_REQUEST['ch'];
	    	if(!empty($_REQUEST['c23']))$params['c23']  = $_REQUEST['c23'];
	    	if(!empty($_REQUEST['vid']))$params['vid']  = $_REQUEST['vid'];
	    	if(!empty($_REQUEST['afid']))$params['afid']  = $_REQUEST['afid'];
	    	if(!empty($_REQUEST['ui']))$params['ui']  = $_REQUEST['ui'];

	    	if ($forceLogin === false)
	    		$params = array_merge($params,array('immediate'=>'true'));

	    	$idpUrl = $this->getUrl(
		    $this->_config['ssoBaseUrl'],
		    $this->_config['ssoUrlOauth2Authorize'],
		    		    	$params
		    				);

			error_log('Generated joinsso URL: ' . $idpUrl);
	    	return $idpUrl;
	    }



	    /**
	     * Set a state to avoid CSRF attacks
	     */
	    protected function setState() {
		    if ($this->_state === null) {
		    	$this->_state = md5(uniqid(mt_rand(), true));
		    	$this->getCache()->set('state'.$this->_state, true);
		    	return $this;
		    }
		 }


		/**
	     * Print HTML link ('<a../a>') into Login or Logout page depending if user is logged in or not.
	     * @param array $data Assoc array containing 'login' and/or 'logout' arrays. There needs to be keys: (string) href, (string) label, (array) attributes.
	     */
	    public function printLinkLoginLogout($data = array())
	    {
	    	if (isset($_SESSION['accesstokenInfo'])) {
	    		// user logged in
	    		$data['logout'] = array(
                'href' => isset($data['logout']['href']) ?
	    		$data['logout']['href'] : $this->_defaults['linkHrefLogout'],
                'label' => isset($data['logout']['label']) ?
	    		$data['logout']['label'] : $this->_defaults['linkLabelLogout'],
                'attributes' => isset($data['logout']['attributes']) ?
	    		$data['logout']['attributes'] : $this->_defaults['linkAttributesLogout']
	    		);
	    		return $this->_generateLinkMarkup(
	    		$data['logout']['href'],
	    		$data['logout']['label'],
	    		$data['logout']['attributes']
	    		);
	    	} else {
	    		// user not logged in
	    		if (isset($data['scope']) && !empty($data['scope'])) {
	    			$this->_scope = $data['scope'];
	    		}
	    		$data['login'] = array(
					           'href' => $this->_generateJoinSsoUrl(true),
					           'label' => isset($data['login']['label']) ?
	    		$data['login']['label'] : $this->_defaults['linkLabelLogin'],
					           'attributes' => isset($data['login']['attributes']) ?
	    		$data['login']['attributes'] : $this->_defaults['linkAttributesLogin']
	    		);

	    		return $this->_generateLinkMarkup(
	    		$data['login']['href'],
	    		$data['login']['label'],
	    		$data['login']['attributes']
	    		);
	    	}
	    }

		/**
	     * Generate HTML markup for link. SID attributes are added automatically.
	     * @param string $href
	     * @param string $label
	     * @param array $attributes
	     * @return string HTML <a> tag with given data.
	     */
	    private function _generateLinkMarkup($href, $label, $attributes = array()) {
	    	// put session id as param if needed
	    	if ($this->_config['useSessionCookie'] === false) {
	    		$href .= strpos($href, '?') === false ? // first param?
                '?' . urlencode(SID) :
                '&' . urlencode(SID);
	    	}
	    	$link = '<a href="' . $href . '"';
	    	if (count($attributes)) { // loop attributes if available
	    		foreach ($attributes as $name => $value) {
	    			$link .= ' ' . $name . '="' . $value . '"';
	    		}
	    	}
	    	$link .= '>' . $label . '</a>';
	    	return $link;
	    }

	    /**
	     * End session and redirect user to url defined in session.
	     */
	    public function endSession()
	    {
	    	// get existing session
	    	$this->startSession();

	    	// destroy session
	    	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
	    	$session->destroy();

	    	// clear NOALastLogin cookie too!
	    	$this->setNoaLastLoginCookie(
		    array_merge(
		    $this->getNoaLastLoginCookieData(), //get basic data
		    array('expires' => time() - 60*60) //replace the expiry time to the past (delete)
		    )
		    );

		    // redirect to NoA to clear session globally
		    $header = "Location: " . $this->_config['ssoBaseUrl'] . $this->_config['ssoUrlLogout'] .
            "?returnurl=" . $this->_config['baseUrl'] . $this->_config['logoutDoneUrl'];
		    error_log("header: $header");
		    header($header);
	    }

		/**
	     * Handle account notification from SSO
	     */
	    public function handleNotificationAccount()
	    {
	    	$headers = function_exists('getallheaders') ?
			getallheaders() : array();
			if (isset($headers['Authorization'])) {
				// handle authoriztion header
				$opaqueToken = explode(' ',$headers['Authorization']);
				list($accessTokenInfo, $accessTokenExtInfo) = $this->decryptOpaqueToken($opaqueToken[1]);
			}

            // If decryption is successful, validation is done.
            if (!empty($accessTokenInfo)) {
            	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
            	$xmlString = file_get_contents("php://input");
            	$xmlObject = $this->_parseStringToXml($xmlString);
            	// require user class
            	require_once 'Nokia/Sso/User.php';
            	$output = array(
                'type' => (string) $xmlObject->type,
    		    'user' => new Nokia_Sso_User( $xmlObject->account )
            	);
            	return $output;
            }
	    }

	    public function forceLogin($params = NULL) {
            $this->startSession();
            $this->createSession();

            $url = $this->_generateJoinSsoUrl(TRUE);

            if ($params) {
                $pairs = array();
                foreach ($params as $name=>$value) {
	    			$pairs[] = "$name=".urlencode($value);
	    		}
                $url .= (strpos($url, "?") ? "&" : "?").implode("&", $pairs);
            }
            header("Location: $url");
            exit;
        }

}