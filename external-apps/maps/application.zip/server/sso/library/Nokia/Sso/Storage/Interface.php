<?php
/**
 * Nokia SSO library - session storage interface.
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
interface Nokia_Sso_Storage_Interface
{
	/**
	 * Get session data from storage with $key
	 * @param string $key
	 */
	public function get($key);

	/**
	 * Set data into storage with $key
	 * @param string $key
	 * @param array $value
	 * @param int $lifeTime Optional lifeTime if supported
	 */
	public function set($key, $value, $lifeTime);

	/**
	 * Delete data with $key
	 * @param string $key
	 */
	public function delete($key);
}