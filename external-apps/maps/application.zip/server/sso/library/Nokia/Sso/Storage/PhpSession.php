<?php
/** Nokia_Sso_Storage_Interface */
require_once  'Nokia/Sso/Storage/Interface.php';

/**
 * Nokia SSO library - session handling using native PHP Session backend
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Storage_PhpSession implements Nokia_Sso_Storage_Interface
{
	/**
	 * Constructor
	 * @param array $config
	 */
	public function __construct($config) {
		if (isset($config['sessionName'])) {
			session_name($config['sessionName']);
		}
	}

	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::get()
	 */
	public function get($key) {
		session_id($key);
		@session_start();
		return isset($_SESSION) ? $_SESSION : array();
	}

	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::set()
	 */
	public function set($key, $value, $lifeTime) {
		// Below line creates problem for authorization request validation.
		if (isset($_SESSION))
		$_SESSION[$key] = $value;
	}

	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::delete()
	 */
	public function delete($key) {
		//if session storage type is 'phpsession', this is just a work around to destroy a
		//session in back channel call if session save handler is set to 'files' in php.ini file.
		$sessionHandler = ini_get('session.save_handler');
		if ($sessionHandler == 'files')
		{
			$path = ini_get('session_save_path');
			if (empty($path)) $path = '/tmp/';
			if(file_exists($path.'sess_'.$key)) {
				unlink($path.'sess_'.$key);
			}
		}
		session_unset();
		session_destroy();
	}
}