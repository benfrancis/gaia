<?php
/**
 * Nokia SSO library - exception
 * @author tomkulma
 * @abstract Exception class that parses SSO error response XML into SimpleXML object.
 */
class Nokia_Sso_Exception extends Exception
{
    /**
     * @var SimpleXMLElement $xml
     */
    private $xml = null;

    /**
     * Constructor for exception
     * @param string $message
     * @param code $code
     * @param string $xmlString
     */
    public function __construct($message, $code, $xmlString) {
        $this->xml = @simplexml_load_string($xmlString); //In case of OAuth 1.0, we still get XML response.
        parent::__construct($message, $code);
    }

    /**
     * Get error XML object
     * @return SimpleXMLElement
     */
    public function getXml() {
        return $this->xml;
    }
}