<?php

require_once("../config.php");
require_once("../curl.php");
require_once("testconfig.php");

class SCBEServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        global $CONFIG;
        $url = join("/", array(trim($CONFIG['SCBE_URL'], '/'), 'dataModel/favoritePlace'));
        $this->response = curl($url);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 2s");
    }

    public function testStatus() {
        $this->assertEquals(200, $this->response->status, "Response status code should be 200");
    }

    public function testContentType() {
        $this->assertContains("application/json", $this->response->headers["Content-Type"]);
    }

    protected function tearDown() {}
}