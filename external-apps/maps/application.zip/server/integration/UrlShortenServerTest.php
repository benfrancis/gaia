<?php

require_once("../config.php");
require_once("../curl.php");
require_once("testconfig.php");

class UrlShortenServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        $requestURL = SHORTENERURL;

        $data = array(
            "longUrl" => "http://www.nokia.com/",
            "clientId" => SHORTENERID,
            "clientSecret" => SHORTENERSECRET
        );

        $this->response = curl(array(
            "method" => "POST",
            "url" => $requestURL,
            "data" => $data,
            "curlOptions" => array(CURLOPT_HEADER=>FALSE, CURLOPT_SSL_VERIFYPEER=>FALSE)
        ));
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(2 * EXPRESPONSETIME, $this->response->time, "Response should be faster than 2s");
    }

    public function testStatus() {
        $this->assertEquals(201, $this->response->status, "Response status code should be 201");
    }

    protected function tearDown() {}
}