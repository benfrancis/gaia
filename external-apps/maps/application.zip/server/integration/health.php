<?php
// password protection for the production server
if (@$_SERVER['PHP_AUTH_USER'] != 'olympus' || @$_SERVER['PHP_AUTH_PW'] != 'oneappyeah') {
    header('WWW-Authenticate: Basic realm="MH5 Health"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Please authenticate';
    exit;
}

$title = "Mobile HTML5 project health";

function createTableCell($result) {
    $cls =
    $str = '<td class="';
    if ($result === TRUE) {
        $str .= 'ok';
    } else if ($result === FALSE) {
        $str .= 'error';
    }

    $str .= '">';

    if ($result === TRUE) {
        $str .= 'PASS';
    } else if ($result === FALSE) {
        $str .= 'FAIL';
    } else {
        $str .= 'N/A';
    }

    $str .= '</td>';

    return $str;
}

// capture runners output (xml)
ob_start();
require_once("runner.php");
$contents = ob_get_contents();
ob_end_clean();

// FIXME [chrheinr] looks like on qa/stg/prod we get an addtional newline in front in - needs to be fixed
$xml = new SimpleXMLElement(trim($contents));

$report = array();
for ($i = 0; $i < count($xml->testsuite->testsuite); $i++) {
    $testSuite = $xml->testsuite->testsuite[$i];
    for ($j = 0; $j < count($testSuite->testcase); $j++) {
        $testCase = $testSuite->testcase[$j];

// var_dump($testCase);

        $testName  = str_replace("test", "", (string)$testCase["name"]);
        $className = str_replace("Test", "", (string)$testCase["class"]);
        $status    = !(isset($testCase->{"failure"}));

        if (!$testName || !$className) {
            continue;
        }

        $report[$className][$testName] = $status;
    }
}

// var_dump($report);

?>

<html>
<head>
<title><?php echo $title?></title>
<meta charset="utf-8">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<style>
body {
    font-family: sans-serif;
    font-size: 18px;
    margin: 0;
    padding: 0;
    background-color: #EEE;
    color: #222;
}
.container {
    margin: 20px;
}
header {
    font-size: 20px;
    font-weight: bold;
}
table {
    margin: 10px 0;
    padding: 5px 5px 0;
    background: #FFF;
    width: 100%;
}
td {
    padding: 6px;
}
td.error {
    background-color: #E30450;
    color: #FFF;
}
td.ok {
    background-color: #5CC151;
}
th {
    text-align: left;
    padding: 6px;
}
tr.header td {
    background-color: #FFF;
    font-weight: bold;
}
</style>
</head>

<body>
<header><?php echo $title?></header>
<section>
<table border="0" cellspacing="0" cellpadding="0">
<tr>
<th>Service</th>
<th>Time</th>
<th>Status</th>
<th>Content-Type</th>
<th>JSON</th>
<th>Body</th>
</tr>

<?php foreach ($report as $name=>$results):?>
    <tr>
    <td><?php echo $name?></td>
    <?php echo createTableCell(@$results["ResponseTime"])?>
    <?php echo createTableCell(@$results["Status"])?>
    <?php echo createTableCell(@$results["ContentType"])?>
    <?php echo createTableCell(@$results["Schema"])?>
    </tr>
<?php endforeach?>

</table>
</section>
</body>
</html>