<?php

require_once("PHPUnit/Autoload.php");

class SPTestRunner{

    private static function bfglob($path, $pattern = "*", $flags = 0, $depth = 0) {
      $matches = array();
      $folders = array(rtrim($path, DIRECTORY_SEPARATOR));

      while($folder = array_shift($folders)) {
        $matches = array_merge($matches, glob($folder.DIRECTORY_SEPARATOR.$pattern, $flags));
        if($depth != 0) {
          $moreFolders = glob($folder.DIRECTORY_SEPARATOR."*", GLOB_ONLYDIR);
          $depth   = ($depth < -1) ? -1: $depth + count($moreFolders) - 2;
          $folders = array_merge($folders, $moreFolders);
        }
      }
      return $matches;
    }

  public static function run(){
    // Create the test suite instance
    $suite = new PHPUnit_Framework_TestSuite();

    // look for testfiles in cwd
    $filenames = self::bfglob(".", "*Test.php", 0, -1);

    // Add files to the TestSuite
    $suite->addTestFiles($filenames);

    // Create a xml listener object
    $listener = new PHPUnit_Util_Log_JUnit;

    // Create TestResult object and pass the xml listener to it
    $result = new PHPUnit_Framework_TestResult();
    $result->addListener($listener);

    // Run the TestSuite
    $suite->run($result);

    // Get the results from the listener
    return $listener->getXML();
  }
}

print(trim(SPTestRunner::run()));
?>