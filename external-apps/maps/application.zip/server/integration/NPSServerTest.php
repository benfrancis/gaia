<?php

require_once("../config.php");
require_once("../curl.php");
require_once("testconfig.php");

class NPSServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        $requestURL = NPSURL;
        $this->response = curl($requestURL);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 3s");
    }

    public function testContentType() {
        $this->assertContains("text/xml", $this->response->headers["Content-Type"]);
    }

    protected function tearDown() {}
}
