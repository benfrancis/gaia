<?php

require_once("config.php");
require_once("Http.php");
require_once("Place.php");
require_once("Recommendations.php");

//*****************************************************************************

// check for missing app id and app code

// $_GET["app_id"] = "FLq0p5qyl-3-jTx2ANEi";
// $_GET["app_code"] = "0d03vSmNAytGsZfItsVBQw%253D%253D";

if (!isset($_GET["app_id"]) || !isset($_GET["app_code"])) {
    header("HTTP/1.0 401 Unauthorized");
    echo "Credentials required";
    exit;
}

//*** given place id only: get place details **********************************

if (!isset($_GET["lat"]) || !isset($_GET["lon"])) {

    // use client resolution for image resizing
    if (isset($_GET["ScreenSize"])) {
        $maxDimension = max(explode("x", $_GET["ScreenSize"]));
        Place::$imageWidth  = $maxDimension;
        Place::$imageHeight = $maxDimension;
    }

    if (isset($_GET["placeUrl"])) {
        Http::response( Place::loadByUrl($_GET["placeUrl"], $_GET["geolocation"], $_GET["lang"]) );
        // automatic response + exit
    }

    if (isset($_GET["place"])) {
        Http::response( Place::loadById($_GET["place"], $_GET["app_id"], $_GET["app_code"], $_GET["geolocation"], $_GET["lang"]) );
        // automatic response + exit
    }
}

//*** given latitude/longitude: get recommendations ***************************

// no matter whether for a place or for an address
// if there is a place id given, results are just filtered to not contain the given place

if (isset($_GET["lat"]) && isset($_GET["lon"])) {
    if(true == $_GET["init"]){
        $recomm = Recommendations::explore($_GET["lat"], $_GET["lon"], $_GET["app_id"], $_GET["app_code"], $_GET["geolocation"]);
    }
    else{
        $recomm = Recommendations::find($_GET["lat"], $_GET["lon"], @$_GET["place"], $_GET["app_id"], $_GET["app_code"], $_GET["geolocation"]);
    }
    Http::response(array("recommendations"=>$recomm));
    // automatic response + exit
}
