<?php

/**
 * Recommendations module for Places and Locations
 * can be used standalone like
 * http://yourhost.com/Recommendations.php?lat=52.52&lon=13.37
 */

require_once("config.php");
require_once("Http.php");
require_once("Place.php");
require_once("PublicTransport.php");

class Recommendations extends Place {

    // available categories
    private static $categories = array();

    private static $limitForPlace   = 5;
    private static $limitForAddress = 10;
    private static $limitForExplore = 20;

    /**
     * explore nearby places. Used for starting recommendations
     */
    public static function explore($lat, $lon, $appId, $appCode, $geolocation = NULL) {
        $url = strtr(EXPLOREURL, array(
            "<at>"      => "$lat,$lon",
            "<size>"    => self::$limitForExplore,
            "<appId>"   => $appId,
            "<appCode>" => $appCode
        ));
        if ($geolocation) {
            $url .= '&geolocation=' . urlencode($geolocation);
        }

        $data = Http::get($url);

        $res = array();
        if (!isset($data["results"]) || !isset($data["results"]["items"])){
            return $res;
        }

        $places = $data["results"]["items"];
        for ($i = 0; $i < count($places); $i++) {
            $res[] = self::formatBasicPlace($places[$i]);
        }

        return $res;
    }

    /**
     * load categorized recommendations for a given place and return
     * them in a client-friendly return them in a client-friendly format:
     * "recommendations": { "eat-drink": [...], "shopping": [...], ...}
     * @param string placeId if known (optional)
     */
    public static function find($lat, $lon, $placeId, $appId, $appCode, $geolocation = NULL) {
        // set categories
        self::$categories = array(
            "eating"    => "eat-drink",
            "shopping"  => "shopping",
            "going-out" => "going-out",
            "sights"    => "sights-museums"
        );

        $limit = $placeId ? self::$limitForPlace : self::$limitForAddress;

        $res = array();
        $urls = array();
        foreach (self::$categories as $categClientName=>$categServerName) {
            $url = strtr(RECOMMSURL, array(
                "<at>"      => urlencode("$lat,$lon"),
                "<size>"    => $limit,
                "<cat>"     => $categServerName,
                "<appId>"   => $appId,
                "<appCode>" => $appCode
            ));
            if ($geolocation) {
                $url .= '&geolocation=' . urlencode($geolocation);
            }
            $urls[$categClientName] = $url;
        }

        $req = Http::getMulti($urls);

        $res = array();
        $uniquePlaceIds = array();
        if ($placeId) {
            // filter origin place as well
            $uniquePlaceIds[] = $placeId;
        }

        foreach (self::$categories as $categClientName=>$categServerName) {
            $data = $req[$categClientName];

            if (!isset($data["results"]) || !isset($data["results"]["items"])) continue;

            $places = $data["results"]["items"];

            $res[$categClientName] = array();
            for ($i = 0; $i < count($places); $i++) {
                // don't return duplicate items, use href as identifier
                if (in_array($places[$i]["id"], $uniquePlaceIds)) continue;
                $uniquePlaceIds[] = $places[$i]["id"];

                $basicPlace = self::formatBasicPlace($places[$i]);

                $res[$categClientName][] = $basicPlace;
            }
        }

        $nearbyStations = PublicTransport::find($lat, $lon, $limit);
        if(is_array($nearbyStations)){
            $latLon = array();
            foreach ($nearbyStations as $value) {
                $latLon[] = array("lat" => $value["latitude"], "lon" => $value["longitude"]);
            }
            $addresses = Place::resolveAllAddresses($latLon, $appId, $appCode);
            foreach ($addresses as $key => $value) {
                $nearbyStations[$key]["address"] = $value;
            }
            $res["public-transport"] = $nearbyStations;
        }
        return $res;
    }

    /**
     * formats a simple place object, i.e. search result item
     * @protected
     * @param array $data raw place data object
     * @return array formatted place object
     */
    private static function formatBasicPlace($data) {
        return array(
            "placeId"         => $data["id"],
            "href"            => $data["href"],
            "name"            => $data["title"],
            "categoryGroup"   => $data["category"]["id"], // TODO: use title later
            "hasOwnerContent" => preg_match('#_02#', $data["icon"]),
            "icon"            => $data["icon"],
            "latitude"        => $data["position"][0],
            "longitude"       => $data["position"][1],
            "address"         => $data["vicinity"],
            "ratingValue"     => $data["averageRating"],
            "distance"        => $data["distance"]
        );
    }

    public static function autoResponse($param = NULL) {
        if (!$param || !is_array($param)) {
            return;
        }
        if (basename($_SERVER["PHP_SELF"]) != basename(__FILE__)) {
            return;
        }
        if (isset($param["lat"]) && isset($param["lon"])) {
            $res = self::find($param["lat"], $param["lon"], @$param["placeId"], $param["app_id"], $param["app_code"]);
            Http::response($res);
        }
    }
}

// check, if this got called directly, decide response action according to parameters
Recommendations::autoResponse($_GET);
