<?php
/**
 * follows http://wikis.in.nokia.com/SAS/UShareAPI, adds sectoken as an additional return value
 */
require_once("../config.php");
require_once("../functions.php");
require_once("../curl.php");

// no CORS support currently
// enableCORS();

$isJsonp = isset($_REQUEST["jsonp"]);
$callbackFn = $isJsonp ? $_REQUEST["jsonp"] : "myCallback";
// exit immediately if callback is not valid JS id
exit_on_invalid_jsidentifier($callbackFn);

$contentType = $isJsonp ? "application/javascript; charset=utf-8" : "application/json; charset=utf-8";
$responseText = "{}";

$result = curl(USHAREURL ."auth?skip_sso=true&jsonp=$callbackFn");

if ($result->status == "ERROR") {
    header("HTTP/1.0 500 Service is not responding or delivering invalid data");
    header("Content-Type: $contentType");
    echo $isJsonp ? "$callbackFn($responseText)" : $responseText;
    exit;
}

// get the cookie
list($cName, $cVal) = explode("=", array_shift(explode(";", $result->headers["Set-Cookie"])));
// TODO [chrheinr] as soon as we use personal data  this should be later HTTPOnly (use $_SERVER['SCRIPT_NAME'])
// then cookie stealing could become an issue
setCookie($cName, $cVal, 0, "/");
// analyse response
$pattern = '/'. $callbackFn .'\(\{(.*)\}\);/';
// 1 - jsonp callback, 2 - argument , 3 - closing braces, semicoloon etc.
preg_match($pattern, $result->body, $matches);

header("Content-Type: $contentType");

if ($isJsonp) {
    echo $callbackFn.'({'.$matches[1].',"sectoken":"'. $cVal .'"});';
} else {
    echo '{'. $matches[1] .',"sectoken":"'. $cVal .'"}';
}
