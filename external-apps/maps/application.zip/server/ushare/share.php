<?php
// follows http://wikis.in.nokia.com/SAS/UShareAPI , adds jsonp param
require_once('../config.php');
require_once("../functions.php");
require_once('../curl.php');

// no CORS support currently
// enableCORS();

// jsonp?
$isJsonp = isset($_REQUEST['jsonp']);
$callbackFn = $isJsonp ? $_REQUEST["jsonp"] : "myCallback";
// exit immediately if callback is not valid JS id
exit_on_invalid_jsidentifier($callbackFn);

// handle get an post
$data = isset($_GET) ? $_GET : $_POST;
//add the correct serviceId / clientId
addClientAndServiceParams($data);

$result = curl(array(
    "method" => "POST",
    "url" => USHAREURL ."share",
    "data" => $data,
    "timeout" => 15,
    "cookies" => $_COOKIE
));

header("Content-Type: ". ($isJsonp ? "application/javascript; charset=utf-8" : "application/json; charset=utf-8"));

// jsonp or plain output
if ($isJsonp) {
    echo $callbackFn ."(". $result->body .");";
} else {
    echo $result->body;
}