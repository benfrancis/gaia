<?php
require_once('../config.php');
require_once("../functions.php");

//http://wikis.in.nokia.com/SoLoPublishing/UrlShortenerApi
// Registration data
//{"client":{"urlsCreated":0,"id":55,"email":"leonid.ziskel@nokia.com","secret":"wffCSOKup4hC6wqjUyR5lQ","totalClicks":0}}
//curl -v -k -x http://nokes.nokia.com:8080 -d "longUrl=http://maps.nokia.com/services/place/826gcpuv-f4c5b0f6dee34274a839d6237c98fcd5&clientId=55&clientSecret=wffCSOKup4hC6wqjUyR5lQ" https://u.it.ovi.com/urls.json

$callbackFn = $_REQUEST["jsonp"];
// exit immediately if callback is not valid JS id
exit_on_invalid_jsidentifier($callbackFn);

$data = array(
    "longUrl" => $_REQUEST["longUrl"],
    "clientId" => SHORTENERID,
    "clientSecret" => SHORTENERSECRET
);

//TODO [ziskel] we do curl handling here ignoring curl.php, because curl.php puts much more in the response body then
//we need. Christoph knows about this issue and will take care. :-)
// init curl
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, SHORTENERURL);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_POST, TRUE);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

header("Content-Type: application/javascript; charset=utf-8");

// use proxy if defined and not an empty string
if (defined("PROXY_HOST") && PROXY_HOST) {
    curl_setopt($ch, CURLOPT_PROXY, PROXY_HOST .":". PROXY_PORT);
}

//FIXME [ziskel] currently our dev server can't deal with certificates from the shortener. We have to update the
//certificates there and then we can remove this setting
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);


// do the request
$result = curl_exec($ch);

$decoded = json_decode($result);

if ($decoded && $decoded->url && $decoded->url->shortUrl) {
    echo $callbackFn."({\"shortUrl\": \"".$decoded->url->shortUrl."\"})";
} else {
    echo $callbackFn."({})";
}

