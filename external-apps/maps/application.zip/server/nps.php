<?php
/**
 * The nps.php acts as proxy to the nps server, parameter translation will be performed to the lastest NPS API
 * see http://wikis.in.nokia.com/pub/NPSwidgetWiki/WebHome/NPS_API_v2.0.docx
 *
 *
 * @param $_REQUEST['rec'] will get resend as score parameter
 * @param $_REQUEST['fb-text'] will get resend as feedback
 * @param $_REQUEST['country'] optional
 * @param $_REQUEST['city'] optional
 * @param $_REQUEST['long'] used to get a location
 *
 * @return NPS server response, empty response on timeout
 */

require_once("config.php");
require_once("functions.php");
require_once("curl.php");

// helper to generate zero terminated string
function str_to_nts($value) {
  return "$value\0";
}

// helper to convert a 0 terminated string to php string
function str_from_mem(&$value) {
  $i = strpos($value, "\0");
  if ($i === false) {
   return $value;
  }
  $result =  substr($value, 0, $i);
  return $result;
}

function isDoublePost($aPostId){
    // default return
    $result = TRUE;
    // setup
    $postsToKeep = 10;
    $shm_key = 1946193658;

    $shm_id = shmop_open($shm_key, "c", 0644, 16384);
    $rawString = shmop_read($shm_id, 0, 16384);
    $lastPosts = str_from_mem($rawString);
    if (strpos($lastPosts, $aPostId) === FALSE) {
        // a new feedback
        $arOfPosts = explode(";", $lastPosts);
        // remove not needed ids
        while(count($arOfPosts) >= $postsToKeep) {
            array_shift($arOfPosts);
        }
        // add the new id
        $arOfPosts[] = $aPostId;
        // join everything and write back
        $lastPosts = implode(";", $arOfPosts);
        shmop_write($shm_id, str_to_nts($lastPosts), 0);
        $result = FALSE;
    }
    shmop_close($shm_id);
    return $result;
}

// jsonp
$isJsonp = isset($_REQUEST["jsonp"]);
$callbackFn = $isJsonp ? $_REQUEST["jsonp"] : "myCallback";
// exit immediately if callback is not valid JS id
exit_on_invalid_jsidentifier($callbackFn);


// check for double posts
// last 10 post should be different in terms of IP, score, feedbacktext - we only store a hash
$uniquePostId = md5(trim($_SERVER['REMOTE_ADDR'] . $_REQUEST['rec'] . $_REQUEST['fb-text']));
if (isDoublePost($uniquePostId)) {
    $result = '<?xml version="1.0" encoding="UTF-8"?><response><status>OK</status><message>Double post</message></response>';
    if ($isJsonp) {
        // quote result
        echo "$callbackFn(" . json_encode($result) . ");";
    } else {
        echo $result;
    }
    // END of processing for double posts
    exit;
}

// some settings for rgc
$PUBLIC_KEY = "MH5";
$PUBLIC_REFERER = "PA2EYcR8fw2jjdNkKBUX";
$PUBLIC_AUTH = "?token=" . $PUBLIC_KEY . "&app_id=" . $PUBLIC_REFERER;

// make sure we have an app version
$appversion_workaround = '1.8.16';

// initial query string TODO [chrheinr] fix page URL
$qs = 'score=' . $_REQUEST['rec'];
// check the UserAgent
$agent = $_SERVER['HTTP_USER_AGENT'];

// include location params if present
if (!empty($_REQUEST['city']) && !empty($_REQUEST['country'])) {
    $qs .= '&country=' . urlencode($_REQUEST['country']) . '&city=' . urlencode($_REQUEST['city']);
} else {
    // use internal IP based resolution
    $qs .= '&ip=' . urlencode($_SERVER['REMOTE_ADDR']);
}

// include email, if provided
if (!empty($_REQUEST['email'])) {
    $qs .= '&email=' . urlencode($_REQUEST['email']);
}

// add user agent and version to qs
$qs .= '&feedback=' . urlencode($_REQUEST['fb-text']) . '&releaseVersion=' . urlencode($appversion_workaround);
// user agent
$qs .= '&userAgent=' . urlencode($agent);
// fallback until UA is supported by xls TODO[chrheinr] remove when not needed anymore
$qs .= '&site=' . urlencode($agent);

// add random numbers for error tracking
$qs .= '&genericParameterName=rnd&genericParameterValue=' . $_REQUEST['crnd'] . '_' . rand(0, 1000);

$phonegap = stripos($agent, "phonegap");

// determine device type
$deviceType = "Other";
if (stripos($agent, "android") !== false) {
    $deviceType = "Android";
} elseif (stripos($agent, "iphone") !== false) {
    $deviceType = "iPhone";
} elseif (stripos($agent, "ipod") !== false) {
    $deviceType = "iPhone";
} elseif (stripos($agent, "ipad") !== false) {
    $deviceType = "iPad";
} elseif (stripos($agent, "blackberry") !== false) {
    $deviceType = "BB";
} elseif (stripos($agent, "meego") !== false) {
    $deviceType = "Meego";
} elseif (stripos($agent, "windows phone") !== false) {
    $deviceType = "WM";
}
$qs .= "&device=$deviceType";

$projid = $_REQUEST['projid'];
if ($currentEnv !== 'st' and $currentEnv !== 'pr') {
    $projid = NPSDEVID;
} elseif ($_REQUEST['client'] == 'flame') { // fallback for Flame client
    $projid = NPSFLAMEID;
}

$qs .= "&projid=$projid";

if ($phonegap !== false) {
    if ($deviceType == "Android") {
        $qs .= "&genericParameterName2=pg&genericParameterValue2=pg_android";
    } else {
        $qs .= "&genericParameterName2=pg&genericParameterValue2=pg_ios";
    }
}

// increased timeout since 5s was too low
$result = curl(array(
    "method" => "GET",
    "url" => NPSURL . "?$qs",
    "timeout" => 20
))->body;


if ($isJsonp) {
    // quote result
    echo "$callbackFn(". json_encode($result) .");";
} else {
    echo $result;
}
